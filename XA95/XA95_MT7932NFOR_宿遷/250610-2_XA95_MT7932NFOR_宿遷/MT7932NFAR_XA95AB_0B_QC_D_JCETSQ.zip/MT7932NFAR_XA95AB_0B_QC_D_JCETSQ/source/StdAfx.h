// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_)
#define AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>

#define DUT_API extern "C" __declspec(dllexport)
#include <string>
using namespace std;
#include "usertype.h"
#include "userres.h"


// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_)
// ****************************************************** test flow
// test0    OS_TEST                   , RA
// test1    SupplyCurrent             , RA
// test2    PKGTrimming
// test3    UVLO_Threshold
// test4    EN_Threshold              , RA
// test5    Leakage_Test              , RA
// test6    LeakageBV_Test
// test7    PowerOnDelay
// test8    ReverseBlock
// test9    RB_ResponseTime
// test10   VBUS_DisChargeR           , RA
// test11   VBUS_ActiveDisT
// test12   OVP_Threshold             , RA
// test13   OVP_ResponseTime
// test14   RDSon_Test                , RA
// test15   CurrentMonitor_OutRatio
// test16   IMON_ClampV
// test17   CurrentLimit_Threshold
// test18   CL_ResponseTime
// test19   IMax_Threshold
// test20   ADDR_PD_Current
// test21   INTB_OutputLowV
// test22   INTB_DelayTime
// test22   I2C_AddrCheck(Guarantee by designer)
// test23   reOS_TEST                 , RA
// ****************************************************** test mode
// tm1: frsen = 0v, addr = 0v
// tm2: frsen = 0v, addr = 1v, Discharge timer
// tm3: frsen = 0v, addr = 5v, IMAX current
// tm4: frsen = 1v, addr = 0v, V120 voltage
// tm5: frsen = 1v, addr = 1v
// tm6: frsen = 1v, addr = 5v
// tm7: frsen = 5v, addr = 0v
// tm8: frsen = 5v, addr = 1v
// tm9: frsen = 5v, addr = 5v, Post package trim
// ****************************************************** VI source
// ****************************************************** pin definition of XA95AB (MT7932NFAR)
// pin1         IMON2
// pin2         GND
// pin3         ADDR
// pin4         FRSEN
// pin5         EN
// pin6, 16     VBUS2
// pin7, 15     MOUT
// pin8, 14     VBUS1
// pin9         VCC
// pin10        SCL
// pin11        SDA
// pin12        INTB
// pin13        IMON1
// ****************************************************** relay control
// unused, cbit 3, 4, 7, 9, 14, 35, 38, 46

// SITE1
#define SCL_FoviS1				5
#define SDA_FoviS1        6
#define FRSEN_FoviS1      13
#define IMON1_FoviS1      39
#define ADDR_FoviS1       32
#define INTB_FoviS1       10
#define IMON2_FoviS1      15
#define INTB_100K_FoviS1  8
#define VCC_FoviS1        12
#define EN_FoviS1         33
// FPVI_PLUS ****************************************************************** FPVI_PLUS
#define VBUS1_FpviS1      11
#define VBUS2_FpviS1      37
#define MOUT_Fpvi					36
// CAPACITOR ****************************************************************** CAPACITOR
#define VCC_CapS1         0
#define VBUS1_CapS1       1
#define VBUS2_CapS1       2
#define MOUT_CapS1        40
// QTMU *********************************************************************** QTMU
#define VBUS1_QTMUU0AS1   43
#define VBUS2_QTMUU0BS1   44
#define INTB_QTMUU0AS1    45
#define QTMU_SweepS1      47
// 
#define EN_MOUT_ShortS1   41
#define EXT_SCL_SDAS1     42
#define IMON_1KS1         34


// SITE2
#define SCL_FoviS2        69
#define SDA_FoviS2        70
#define FRSEN_FoviS2      77
#define IMON1_FoviS2      103
#define ADDR_FoviS2       96
#define INTB_FoviS2       74
#define IMON2_FoviS2      79
#define INTB_100K_FoviS2  72
#define VCC_FoviS2        76
#define EN_FoviS2         97
// FPVI_PLUS ************************************************************ FPVI_PLUS
#define VBUS1_FpviS2      75
#define VBUS2_FpviS2      101
#define MOUT_FpviS2       100
// CAPACITOR ************************************************************ CAPACITOR
#define VCC_CapS2         64
#define VBUS1_CapS2       65
#define VBUS2_CapS2       66
#define MOUT_CapS2        104
// QTMU ***************************************************************** QTMU
#define VBUS1_QTMUU0AS2   107
#define VBUS2_QTMUU0BS2   108
#define INTB_QTMUU0AS2    109
#define QTMU_SweepS2      111
// 
#define EN_MOUT_ShortS2   105
#define EXT_SCL_SDAS2     106
#define IMON_1KS2         98
