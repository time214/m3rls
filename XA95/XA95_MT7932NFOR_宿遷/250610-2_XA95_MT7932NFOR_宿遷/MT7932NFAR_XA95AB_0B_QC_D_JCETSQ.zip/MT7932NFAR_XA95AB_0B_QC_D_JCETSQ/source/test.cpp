/*
888b     d888 88888888888 8888888888  .d8888b.   .d8888b.   .d8888b.  888b    888 8888888888     d8888 8888888b.  
8888b   d8888     888           d88P d88P  Y88b d88P  Y88b d88P  Y88b 8888b   888 888           d88888 888   Y88b 
88888b.d88888     888          d88P  888    888      .d88P        888 88888b  888 888          d88P888 888    888 
888Y88888P888     888         d88P   Y88b. d888     8888"       .d88P 888Y88b 888 8888888     d88P 888 888   d88P 
888 Y888P 888     888      88888888   "Y888P888      "Y8b.  .od888P"  888 Y88b888 888        d88P  888 8888888P"  
888  Y8P  888     888       d88P            888 888    888 d88P"      888  Y88888 888       d88P   888 888 T88b   
888   "   888     888      d88P      Y88b  d88P Y88b  d88P 888"       888   Y8888 888      d8888888888 888  T88b  
888       888     888     d88P        "Y8888P"   "Y8888P"  888888888  888    Y888 888     d88P     888 888   T88b
*/
#include "stdafx.h"
#include "math.h"

int Debug_tool = 0;
int Time_tool = 0;
bool TC = FALSE;

#define SITENUM	2
#define LogicHi 5.0f
#define LogicLo 0.0f

//#define NonShrink

short I2C_speed = 100;							// 100us, 10Khz
short site = 0, SLVaddr = 0x90, SLVaddrC = 0x96;

double Tmpv = 0.0f;
double adresult[SITENUM]  = { 999 };
double adresult1[SITENUM] = { 999 }, adresult2[SITENUM] = { 999 };

// Package Trimming, 0:default
int  PPTBit1[SITENUM] = { 0, 0 };   // VCC voltage adjustVCC                         [0] 5.2V(default)	[1] 5.48V
int  PPTBit2[SITENUM] = { 0, 0 };   // Ideal diode forward regulation
																		// voltage adjust threshold                      [0] 17mV(default) [1] 25mV
int  PPTBit3[SITENUM] = { 0, 0 };   // Decrease charge pump frequency
																		// to reduce currentreduce                       [0] No frequency foldback
																		//																							 [1] Charge pump frequency foldback
int  PPTBit4[SITENUM] = { 0, 0 };   // Adjust bias current accuracy refer            [5:4]
int  PPTBit5[SITENUM] = { 0, 0 };   // to EN pin pull down resistor                  [00] (default)
																		//																							 [01] +7.4%
																		//																							 [10] -12.2%
																		//																							 [11] -6.5%
int  PPTBit6[SITENUM] = { 0, 0 };   // Power Mos gate pull down current adjust       [0] (default)	[1] Add gate pull down current
int  PPTBit7[SITENUM] = { 0, 0 };   // Soft start charge current adjust              [0] (default)  [1] Add soft start charge current
int  PPTBit8[SITENUM] = { 0, 0 };		// PPTBit4 and PPTBit5
// FPVI_PLUS
FPVI10 FPVI_VBUS1       (0);  // vbus1
FPVI10 FPVI_VBUS2       (2);  // vbus2
FPVI10 FPVI_MOUT        (3);  // mout
// FOVI
FOVI FOVI_SCL           (0);  // scl
FOVI FOVI_SDA           (1);  // sda
FOVI FOVI_FRSEN         (2);  // frs_en
FOVI FOVI_IMON1         (3);  // imon1
FOVI FOVI_ADDR          (4);  // addr
FOVI FOVI_INTB          (6);  // intb
FOVI FOVI_IMON2         (7);  // imon2
FOVI FOVI_VCC           (10); // vcc
FOVI FOVI_EN            (12); // en
FOVI foviSCHK           (15); // fovi for site check

FOVI FOVI_INTB_100K     (9);  // intb series 100K, intb control voltage
QTMU_PLUS qtmu0(0);
CBIT128 cbit128;
// Site1, Site2
// FOVI *********************************************************************** FOVI
#define SCL_Fovi         5,   69   // Relay K6,  fovi chan0
#define SDA_Fovi         6,   70   // Relay K7,  fovi chan1
#define FRSEN_Fovi       13,  77   // Relay K14, fovi chan2
#define IMON1_Fovi       39,  103  // Relay K24, fovi chan3
#define ADDR_Fovi        32,  96   // Relay K17, fovi chan4
#define INTB_Fovi        10,  74   // Relay K11, fovi chan6
#define IMON2_Fovi       15,  79   // Relay K16, fovi chan7
#define INTB_100K_Fovi   8,   72   // Relay K9,  fovi chan9
#define VCC_Fovi         12,  76   // Relay K13, fovi chan10
#define EN_Fovi          33,  97   // Relay K18, fovi chan12
// FPVI_PLUS ****************************************************************** FPVI_PLUS
#define VBUS1_Fpvi       11,  75   // Relay K12, fpvi chan0
#define VBUS2_Fpvi       37,  101  // Relay K22, fpvi chan2
#define MOUT_Fpvi        36,  100  // Relay K21, fpvi chan3
// CAPACITOR ****************************************************************** CAPACITOR
#define VCC_Cap          0,   64   // Relay K1,  VCC CAP
#define VBUS1_Cap        1,   65   // Relay K2,  BUS1 CAP
#define VBUS2_Cap        2,   66   // Relay K3,  BUS2 CAP
#define MOUT_Cap         40,  104  // Relay K25, OUT CAP
// QTMU *********************************************************************** QTMU
#define VBUS1_QTMUU0A    43,  107  // Relay K28
#define VBUS2_QTMUU0B    44,  108  // Relay K29
#define INTB_QTMUU0A     45,  109  // Relay K30
#define QTMU_Sweep       47,  111  // Relay K32, exchange qtmu.a and qtmu.b
// 
#define EN_MOUT_Short    41,  105  // Relay K26
#define EXT_SCL_SDA      42,  106  // Relay K27, pull up resistance
#define IMON_1K          34,  98   // Relay K19, imon1/2 series 1Kohm to GND

#define VCC_Cap_S1				0
#define VCC_Cap_S2			 64
#define VBUS1_Cap_S1			1
#define VBUS1_Cap_S2		 65
#define VBUS2_Cap_S1			2
#define VBUS2_Cap_S2		 66
#define MOUT_Cap_S1		   40
#define MOUT_Cap_S2		   104

// multisite settings should be included here
DUT_API void HardWareCfg()	{
	StsSetModuleToSite(MD_FPVI10, SITE_1, 0, 1, 2, 3, -1);    																												// set channels 0-3 to SITE1
	StsSetModuleToSite(MD_FPVI10, SITE_2, 4, 5, 6, 7, -1);    																												// set channels 4-7 to SITE2
	StsSetModuleToSite(MD_FOVI, SITE_1,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, -1);          // set channels 0-15 to SITE1
	StsSetModuleToSite(MD_FOVI, SITE_2, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, -1);          // set channels 16-31 to SITE2
	StsSetModuleToSite(MD_QTMUPLUS, SITE_1, 0, 1 ,-1);        																												// set channel 0-1 to SITE1
	StsSetModuleToSite(MD_QTMUPLUS, SITE_2, 2, 3 ,-1);        																												// set channel 2-3 to SITE2
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//initialize function will be called before all the test functions.
DUT_API void InitBeforeTestFlow()	{
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
//initializefunction will be called after all the test functions.
DUT_API void InitAfterTestFlow()	{
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
//Fail site hardware set function will be called after failed params, it can be called for serveral times.
DUT_API void SetupFailSite(const unsigned char*byFailSite)	{
}
void pkgTrimming_r(int time)	{
	int ki = 0;
	for (ki = 0; ki < time;)	{
		FOVI_INTB.Set(FV, float(0), FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(100);
		FOVI_INTB.Set(FV, float(5), FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(100);
	}
	FOVI_INTB.Set(FV, float(0), FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(100);
	FOVI_INTB.Set(FV, float(5), FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(100);
	FOVI_INTB.Set(FV, float(0), FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(100);
}

// ********************************************************** TEST MODE ROUTINE **********************************************************
// ********************************************************** TEST MODE ROUTINE **********************************************************
void setupTM(float vbus, float vcc, float ven) {
  // enter TEST mode setting voltage
	FPVI_VBUS2.Set(FV, float(vbus), FPVI10_10V, FPVI10_10A, RELAY_ON);
	FPVI_VBUS1.Set(FV, float(vbus), FPVI10_10V, FPVI10_10A, RELAY_ON);
	FOVI_VCC.Set  (FV, float(vcc), FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI_EN.Set   (FV, float(ven), FOVI_10V, FOVI_100MA, RELAY_ON);
  delay_ms(1);
	FOVI_FRSEN.Set(FV, float(vcc + 1.2), FOVI_10V, FOVI_1A, RELAY_ON);
	FOVI_ADDR.Set(FV, float(vcc + 1.2), FOVI_10V, FOVI_1A, RELAY_ON);
  delay_us(500);
  // release FRSEN & ADDR, chip is latched in TM
  // To exit TM, recycle EN pin to zero
}
void TM_SEL(float vfrsen, float vaddr)  {
	FOVI_FRSEN.Set(FV, float(vfrsen), FOVI_10V, FOVI_1A, RELAY_ON);
	FOVI_ADDR.Set(FV, float(vaddr), FOVI_10V, FOVI_1A, RELAY_ON);
  delay_us(500);
}

// ************************************************************ IIC ROUTINE **************************************************************
// ************************************************************ IIC ROUTINE **************************************************************
// speed 10Khz, 100us
void IIC_Start(void)  {
	FOVI_SDA.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);   // bus idle
	FOVI_SCL.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(I2C_speed);
	FOVI_SDA.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);   // data high to low
	delay_us(I2C_speed);
	FOVI_SCL.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(I2C_speed);
}
void IIC_Stop(void) {
	FOVI_SDA.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_SCL.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(I2C_speed);
	FOVI_SCL.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);   // clk low to high
	delay_us(I2C_speed);
	FOVI_SDA.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);   // data low to high
	delay_us(I2C_speed);
}
unsigned char IIC_Wait_Ack(void)  {
	FOVI_SDA.Set(FI, 0.0e-12f, FOVI_10V, FOVI_10UA, RELAY_SENSE_ON);
	FOVI_SCL.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(I2C_speed);
	FOVI_SCL.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(I2C_speed);

	return 0;
}
void IIC_Ack(void)  {
	FOVI_SCL.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);
  FOVI_SCL.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(I2C_speed);
	FOVI_SCL.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(I2C_speed);
}
void IIC_NAck(void) {
	FOVI_SCL.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(I2C_speed);
  FOVI_SCL.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(I2C_speed);
	FOVI_SCL.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(I2C_speed);
}
void IIC_Send_Byte(unsigned char txd) {
	unsigned char t;

  FOVI_SCL.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
  for(t = 0; t < 8; t++)  {
    if((txd & 0x80) >> 7)
		  FOVI_SDA.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);
	  else
			FOVI_SDA.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);

	  txd <<= 1;
	  delay_us(I2C_speed);
    FOVI_SCL.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);
	  delay_us(I2C_speed);
		FOVI_SCL.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);
	  delay_us(I2C_speed);
  }
}
unsigned char *IIC_Read_Byte(unsigned char *ReVel)  {
  unsigned char g, receive[2] = {0};
	double IIC_SDA_V[2] = {0.0f};
	int p1 = 0;

	FOVI_SDA.Set(FI, 0.0e-12f, FOVI_10V, FOVI_10UA, RELAY_SENSE_ON);
  delay_us(I2C_speed);
  for(g = 0; g < 8; g++ ) {
		FOVI_SCL.Set(FV, LogicLo, FOVI_10V, FOVI_10MA, RELAY_ON);
	  delay_us(I2C_speed);
    FOVI_SCL.Set(FV, LogicHi, FOVI_10V, FOVI_10MA, RELAY_ON);
	  delay_us(I2C_speed);
    FOVI_SDA.MeasureVI(10, 10);

		for(p1 = 0; p1 < SITENUM; p1++)  {
			receive[p1] <<= 1;
			IIC_SDA_V[p1] = FOVI_SDA.GetMeasResult(p1, MVRET);

			if(IIC_SDA_V[p1] > 2.5f)
					receive[p1]++;
		}
	}
  IIC_NAck();
	ReVel[0] = receive[0];
	ReVel[1] = receive[1];

	return receive;
}
unsigned char *IIC_READ(unsigned char SlaveAddr, unsigned char RegAddr, unsigned char *ReVel) {
	unsigned char iicdata[2] = {0};
IIC_READ_Begin:
	IIC_Start();

	IIC_Send_Byte(SlaveAddr);
	if(IIC_Wait_Ack())
		goto IIC_READ_Begin;

	IIC_Send_Byte(RegAddr);
	if(IIC_Wait_Ack())
		goto IIC_READ_Begin;
	IIC_Start();

	IIC_Send_Byte(SlaveAddr+1);
  if(IIC_Wait_Ack())
		goto IIC_READ_Begin;

	IIC_Read_Byte(iicdata);
	IIC_Stop();
  ReVel[0]=iicdata[0];
  ReVel[1]=iicdata[1];

	return iicdata;
}
void IIC_WRITE(unsigned char SlaveAddr, unsigned char RegAddr, unsigned char data)  {
IIC_WRITE_Begin:
	IIC_Start();

	IIC_Send_Byte(SlaveAddr);	// 2.4ms
	if(IIC_Wait_Ack())				// 0.2ms
		goto IIC_WRITE_Begin;

	IIC_Send_Byte(RegAddr);		// 2.4ms
	if(IIC_Wait_Ack())				// 0.2ms
		goto IIC_WRITE_Begin;

	IIC_Send_Byte(data);			// 2.4ms
	if(IIC_Wait_Ack())				// 0.2ms
		goto IIC_WRITE_Begin;

	IIC_Stop();
}
// ************************************************************ PWR ROUTINE **************************************************************
// ************************************************************ PWR ROUTINE **************************************************************
void pwrUP_CAP(unsigned char cap, unsigned char sel)	{
	cbit128.SetOn(VCC_Cap, VBUS1_Cap, VBUS2_Cap, MOUT_Cap, -1);
	delay_ms(1);
}
void pwrVI_RLY(unsigned char cap)	{
	if(cap)
		cbit128.SetOn(VCC_Cap, VBUS1_Cap, VBUS2_Cap, MOUT_Cap,
									SCL_Fovi, SDA_Fovi, FRSEN_Fovi, IMON1_Fovi, ADDR_Fovi, INTB_Fovi, IMON2_Fovi, VCC_Fovi, EN_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, MOUT_Fpvi, -1);
	else
		cbit128.SetOn(SCL_Fovi, SDA_Fovi, FRSEN_Fovi, IMON1_Fovi, ADDR_Fovi, INTB_Fovi, IMON2_Fovi, VCC_Fovi, EN_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, MOUT_Fpvi, -1);
	delay_ms(1);
}
void pwr0V_SET(void)	{
	// FOVI
	FOVI_EN.Set   (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	FOVI_FRSEN.Set(FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	FOVI_VCC.Set  (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	FOVI_IMON1.Set(FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	FOVI_ADDR.Set (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	FOVI_INTB.Set (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	FOVI_SCL.Set  (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set  (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	// FPVI_PLUS
	FPVI_MOUT.Set (FV, 0.0f, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	//delay_ms(1);
}
void pwrOFF_SET(void)	{
	// FOVI
	FOVI_EN.Set   (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_OFF);
	FOVI_FRSEN.Set(FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_OFF);
	FOVI_VCC.Set  (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_OFF);
	FOVI_IMON1.Set(FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_OFF);
	FOVI_IMON2.Set(FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_OFF);
	FOVI_ADDR.Set (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_OFF);
	FOVI_INTB.Set (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_OFF);
	FOVI_SCL.Set  (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_OFF);
	FOVI_SDA.Set  (FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_OFF);
	// FPVI_PLUS
	FPVI_MOUT.Set (FV, 0.0f, FPVI10_2V, FPVI10_10MA, RELAY_OFF);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_2V, FPVI10_10MA, RELAY_OFF);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_2V, FPVI10_10MA, RELAY_OFF);
	//delay_ms(1);
}
void test7_RST(void)	{
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_OFF);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_OFF);
	delay_us(500);
	// ========================================================================
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 3.3f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 3.31f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
}
// ************************************************************ TEST FLOW START **************************************************************
// ************************************************************ TEST FLOW START **************************************************************
// test0, -0.7 ~ -0.4 ***************************************** test0 *****************************************
DUT_API int OS_TEST(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IMON2_GND = StsGetParam(funcindex,"IMON2_GND");
    CParam *ADDR_GND = StsGetParam(funcindex,"ADDR_GND");
    CParam *FRSEN_GND = StsGetParam(funcindex,"FRSEN_GND");
    CParam *EN_GND = StsGetParam(funcindex,"EN_GND");
    CParam *VBUS2_GND = StsGetParam(funcindex,"VBUS2_GND");
    CParam *MOUT_GND = StsGetParam(funcindex,"MOUT_GND");
    CParam *VBUS1_GND = StsGetParam(funcindex,"VBUS1_GND");
    CParam *VCC_GND = StsGetParam(funcindex,"VCC_GND");
    CParam *SCL_GND = StsGetParam(funcindex,"SCL_GND");
    CParam *SDA_GND = StsGetParam(funcindex,"SDA_GND");
    CParam *INTB_GND = StsGetParam(funcindex,"INTB_GND");
    CParam *IMON1_GND = StsGetParam(funcindex,"IMON1_GND");
    CParam *MOUT_VBUS1 = StsGetParam(funcindex,"MOUT_VBUS1");
    CParam *MOUT_VBUS2 = StsGetParam(funcindex,"MOUT_VBUS2");
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	cbit128.SetOn(-1);
	delay_ms(1);
	pwrVI_RLY(0);	// without CAP
	pwr0V_SET();

	// MOUT
	FPVI_MOUT.Set(FI, -1.0e-3, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_us(300);
	FPVI_MOUT.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		MOUT_GND->SetTestResult(site, 0, FPVI_MOUT.GetMeasResult(site, MVRET));
	FPVI_MOUT.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);

	// VBUS1
	FPVI_VBUS1.Set(FI, -1.0e-3, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_us(300);
	FPVI_VBUS1.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		VBUS1_GND->SetTestResult(site, 0, FPVI_VBUS1.GetMeasResult(site, MVRET));
	FPVI_VBUS1.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);

	// VBUS2
	FPVI_VBUS2.Set(FI, -1.0e-3, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_us(300);
	FPVI_VBUS2.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		VBUS2_GND->SetTestResult(site, 0, FPVI_VBUS2.GetMeasResult(site, MVRET));
	FPVI_VBUS2.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);

	// EN
	FOVI_EN.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_EN.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		EN_GND->SetTestResult(site, 0, FOVI_EN.GetMeasResult(site, MVRET));
	FOVI_EN.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// FRSEN
	FOVI_FRSEN.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_FRSEN.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		FRSEN_GND->SetTestResult(site, 0, FOVI_FRSEN.GetMeasResult(site, MVRET));
	FOVI_FRSEN.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// VCC
	FOVI_VCC.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_VCC.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		VCC_GND->SetTestResult(site, 0, FOVI_VCC.GetMeasResult(site, MVRET));
	FOVI_VCC.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// IMON1
	FOVI_IMON1.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_IMON1.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		IMON1_GND->SetTestResult(site, 0, FOVI_IMON1.GetMeasResult(site, MVRET));
	FOVI_IMON1.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// IMON2
	FOVI_IMON2.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_IMON2.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		IMON2_GND->SetTestResult(site, 0, FOVI_IMON2.GetMeasResult(site, MVRET));
	FOVI_IMON2.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// ADDR
	FOVI_ADDR.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_ADDR.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		ADDR_GND->SetTestResult(site, 0, FOVI_ADDR.GetMeasResult(site, MVRET));
	FOVI_ADDR.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// INTB
	FOVI_INTB.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_INTB.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		INTB_GND->SetTestResult(site, 0, FOVI_INTB.GetMeasResult(site, MVRET));
	FOVI_INTB.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// SCL
	FOVI_SCL.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_SCL.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		SCL_GND->SetTestResult(site, 0, FOVI_SCL.GetMeasResult(site, MVRET));
	FOVI_SCL.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// SDA
	FOVI_SDA.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_SDA.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		SDA_GND->SetTestResult(site, 0, FOVI_SDA.GetMeasResult(site, MVRET));
	FOVI_SDA.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// ==============================================================================
  cbit128.SetOn(VBUS1_Fpvi, MOUT_Fpvi, -1);
	delay_ms(1);
	// MOUT
	FPVI_MOUT.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	// VBUS1
	FPVI_VBUS1.Set(FI, 1.0e-3, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_us(300);
	FPVI_VBUS1.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		MOUT_VBUS1->SetTestResult(site, 0, FPVI_VBUS1.GetMeasResult(site, MVRET));
	FPVI_VBUS1.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);

	// ==============================================================================
  cbit128.SetOn(VBUS2_Fpvi, MOUT_Fpvi, -1);
	delay_ms(1);
	// MOUT
	FPVI_MOUT.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	// VBUS2
	FPVI_VBUS2.Set(FI, 1.0e-3, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_us(300);
	FPVI_VBUS2.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		MOUT_VBUS2->SetTestResult(site, 0, FPVI_VBUS2.GetMeasResult(site, MVRET));
	FPVI_VBUS2.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);

  // =============================================================================
	pwrOFF_SET();
	cbit128.SetOn(-1);
	////delay_us(100);

	return 0;
}
// test1, 300uA ~ 700uA ***************************************** test1 *****************************************
DUT_API int SupplyCurrent(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IQ_VBS1_5V = StsGetParam(funcindex,"IQ_VBS1_5V");     // cancel, removed
    CParam *IQ_VBS1_33V = StsGetParam(funcindex,"IQ_VBS1_33V");
    CParam *IQ_VBS2_5V = StsGetParam(funcindex,"IQ_VBS2_5V");     // cancel, removed
    CParam *IQ_VBS2_33V = StsGetParam(funcindex,"IQ_VBS2_33V");   // removed604
    CParam *ISD_VBS1_5V = StsGetParam(funcindex,"ISD_VBS1_5V");   // cancel, removed
    CParam *ISD_VBS1_33V = StsGetParam(funcindex,"ISD_VBS1_33V");
    CParam *ISD_VBS2_5V = StsGetParam(funcindex,"ISD_VBS2_5V");   // cancel, removed
    CParam *ISD_VBS2_33V = StsGetParam(funcindex,"ISD_VBS2_33V"); // removed604
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double IQ_VBS1_5V_C[SITENUM]	= {0.0f}, IQ_VBS2_5V_C[SITENUM]		= {0.0f}, IQ_VBS1_36V_C[SITENUM]	= {0.0f}, IQ_VBS2_36V_C[SITENUM]	= {0.0f};
	double ISD_VBS1_5V_C[SITENUM]	= {0.0f}, ISD_VBS2_5V_C[SITENUM]	= {0.0f}, ISD_VBS1_36V_C[SITENUM] = {0.0f}, ISD_VBS2_36V_C[SITENUM]	= {0.0f};
	double vCHK[SITENUM] = { 0.0f };

  cbit128.SetOn(VBUS1_Cap, VBUS2_Cap, MOUT_Cap, VCC_Cap,
								EN_Fovi, ADDR_Fovi, INTB_Fovi, VBUS1_Fpvi, VBUS2_Fpvi,
								EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, IMON_1K, -1);
	delay_ms(1);
	pwr0V_SET();
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
	// ======================================================================================== Quiescent current
	FOVI_INTB.Set(FV, 5.0f, FOVI_10V, FOVI_100UA, RELAY_ON);
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
  FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_ms(1);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=B4h
  IIC_WRITE(SLVaddr, 0x04, 0xB4);

	// VBUS1 = 33V =================================================, version XA95AB
	FPVI_VBUS1.Set(FV, 33.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_ms(1);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	delay_ms(1);//10
 	FPVI_VBUS1.MeasureVI(50, 5);

	for (site = 0; site < SITENUM; site++)
		vCHK[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

	if ((vCHK[0] > float(32.8)) && (vCHK[1] > float(32.8)))	{
		for (site = 0; site < SITENUM; site++)	{
			IQ_VBS1_36V_C[site] = FPVI_VBUS1.GetMeasResult(site, MIRET);
			IQ_VBS1_36V_C[site] += float(-0e-6);	// offset
		}
	}
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_ms(1);
  FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
  FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_10MA, RELAY_OFF);
	delay_us(500);

	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON, 3);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_OFF);
	delay_us(500);

  FPVI_VBUS1.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
#ifdef NonShrink
	// VBUS2 = 33V ==================================================== version XA95AB
	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
  FPVI_VBUS1.Set(FI, -5.0e-3f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
#endif

	// I2C
	// R=03h, D=E2h
  IIC_WRITE(SLVaddr, 0x03, 0xE2);
	// R=04h, D=B4h
  IIC_WRITE(SLVaddr, 0x04, 0xB4);
	FPVI_VBUS2.Set(FV, 33.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_ms(1);
  // I2C
	// R=03h, D=E2h
	IIC_WRITE(SLVaddr, 0x03, 0xE2);
	delay_ms(1);//10
#ifdef NonShrink
	FPVI_VBUS2.MeasureVI(50, 5);
	for (site = 0; site < SITENUM; site++)
		vCHK[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

	if ((vCHK[0] > float(32.8)) && (vCHK[1] > float(32.8)))	{
		for (site = 0; site < SITENUM; site++)	{
			IQ_VBS2_36V_C[site] = FPVI_VBUS2.GetMeasResult(site, MIRET);
			IQ_VBS2_36V_C[site] += float(120e-6);	// offset
		}
	}
#endif
  FPVI_VBUS1.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_OFF);
//#ifdef NonShrink
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_OFF);
  FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
//#endif
	delay_ms(1);
  // ======================================================================================== Shutdown current
	cbit128.SetOn(VCC_Cap,
								ADDR_Fovi, INTB_Fovi, VBUS1_Fpvi, VBUS2_Fpvi,
								EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, IMON_1K, -1);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=B8h
  IIC_WRITE(SLVaddr, 0x03, 0xB8);		// DISABLE OVP
  FPVI_VBUS2.Set(FI, -10.0e-3f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);

	// EN = 0V
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);

	// VBUS1 = 5V ==========================================================
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_ms(20);
  FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
#ifdef NonShrink
 	FPVI_VBUS1.MeasureVI(50, 5);
  for(site = 0; site < SITENUM; site++)
		ISD_VBS1_5V_C[site] = FPVI_VBUS1.GetMeasResult(site, MIRET);
#endif
	// VBUS1 = 33V ===========================================================
	FPVI_VBUS1.Set(FV, 33.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.MeasureVI(20, 10);// (200, 20);
  for(site = 0; site < SITENUM; site++)
		ISD_VBS1_36V_C[site] = FPVI_VBUS1.GetMeasResult(site, MIRET);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_OFF);
	delay_us(500);
#ifdef NonShrink
	// VBUS2 = 5V ==========================================================
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=E2h
	IIC_WRITE(SLVaddr, 0x03, 0xE2);

	// VBUS2 = 33V ===========================================================
	FPVI_VBUS2.Set(FV, 33.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);

 	FPVI_VBUS2.MeasureVI(200, 20);
  for(site = 0; site < SITENUM; site++)
  	ISD_VBS2_36V_C[site] = FPVI_VBUS2.GetMeasResult(site, MIRET);

	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_OFF);
	delay_ms(1);
#endif
	// ========================================================================================
#ifdef NonShrink
  pwr0V_SET();
  pwrOFF_SET();
	cbit128.SetOn(-1);
#endif

  for(site = 0; site < SITENUM; site++)	{
		IQ_VBS1_33V	->SetTestResult(site, 0, IQ_VBS1_36V_C[site]	*1.0e6f);
  	ISD_VBS1_33V->SetTestResult(site, 0, ISD_VBS1_36V_C[site]	*1.0e6f);
#ifdef NonShrink
	 	IQ_VBS2_33V	->SetTestResult(site, 0, IQ_VBS2_36V_C[site]	*1.0e6f);
	 	ISD_VBS2_33V->SetTestResult(site, 0, ISD_VBS2_36V_C[site]	*1.0e6f);
#endif
	}
  return 0;
}
// test3 ***************************************** test3 *****************************************
DUT_API int UVLO_Threshold(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VBS1_R = StsGetParam(funcindex,"VBS1_R");
    CParam *VBS1_F = StsGetParam(funcindex,"VBS1_F");
    CParam *VBS1_VHYS = StsGetParam(funcindex,"VBS1_VHYS");
    CParam *VBS2_R = StsGetParam(funcindex,"VBS2_R");         // removed604
    CParam *VBS2_F = StsGetParam(funcindex,"VBS2_F");         // removed604
    CParam *VBS2_VHYS = StsGetParam(funcindex,"VBS2_VHYS");   // removed604
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double VBS1_R_V[SITENUM]	= {0.0f},	VBS1_F_V[SITENUM]	= {0.0f},	VBS1_VHYS_V[SITENUM] = {0.0f};
	double VBS2_R_V[SITENUM]	= {0.0f},	VBS2_F_V[SITENUM]	= {0.0f},	VBS2_VHYS_V[SITENUM] = {0.0f};
	double VBUS1_V[SITENUM]		= {0.0f},	VBUS2_V[SITENUM]	= {0.0f};
	double vr1[3] = { 2.94f, 3.05f, 3.25f };		// rising
	double vr2[3] = { 3.25f, 2.75f, 2.55f };		// falling
	short GONOGO = VBS1_R->GetConditionCurSelDouble("goPassFail");	// 0:Ramp	1:P/F

	int flag[SITENUM] = {0};
	BYTE sitesta[SITENUM] = {0};

  cbit128.SetOn(VBUS1_Cap, VBUS2_Cap, MOUT_Cap, VCC_Cap,
								ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EN_Fovi,
								EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, IMON_1K, -1);
	delay_ms(1);
	pwr0V_SET();
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_OFF);
  // =====================================================================================
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);

	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_ms(1);

	FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	FPVI_VBUS1.Set(FV, 2.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 2.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);

  for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
  for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO(H), VBUS1 *******************************************
	if (GONOGO)	{
		// V1
		FPVI_VBUS1.Set(FV, vr1[0], FPVI10_10V, FPVI10_1A, RELAY_ON);
  	delay_ms(1);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && (VBUS2_V[site] > 1.5f))	{
 				VBS1_R_V[site] = vr1[0];
 				flag[site] = 1;
 			}
		}
		// V2
		FPVI_VBUS1.Set(FV, vr1[1], FPVI10_10V, FPVI10_1A, RELAY_ON, 5);
  	delay_ms(1);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && (VBUS2_V[site] > 1.5f))	{
 				VBS1_R_V[site] = vr1[1];
 				flag[site] = 1;
 			}
		}

		// V3
		FPVI_VBUS1.Set(FV, vr1[2], FPVI10_10V, FPVI10_1A, RELAY_ON);
  	delay_ms(1);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
 			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if((flag[site] == 0) && (VBUS2_V[site] > 1.5f))	{
				VBS1_R_V[site] = vr1[2];
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING(H), VBUS1 *******************************************
	else {
		for(Tmpv = 2.78f; Tmpv <= 3.5f;)	{
			FPVI_VBUS1.Set(FV, Tmpv, FPVI10_10V, FPVI10_1A, RELAY_ON);
  		delay_us(100);
			FPVI_VBUS1.MeasureVI(20, 10);
			FPVI_VBUS2.MeasureVI(20, 10);

			for(site = 0; site < SITENUM; site++)	{
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

  			if((flag[site] == 0) && (VBUS2_V[site] > 1.5f))	{
  				VBS1_R_V[site] = Tmpv;
  				flag[site] = 1;
  			}
  		}

  		if((flag[0] == 1) && (flag[1] == 1))
				break;
			if(Tmpv <= 2.98f) Tmpv += 10e-3f;
			else Tmpv += 5e-3f;
 		}
	}
  // =====================================================================================
	FPVI_VBUS1.Set(FV, 4.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);//, 5);
	delay_ms(1);

 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

	StsGetSiteStatus(sitesta, SITENUM);
	for(site = 0; site < SITENUM; site++)		{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO(L), VBUS1 *******************************************
	if (GONOGO)	{
		// V4
		FPVI_VBUS1.Set(FV, vr2[0], FPVI10_10V, FPVI10_1A, RELAY_ON);
  	delay_ms(2);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && ((VBUS1_V[site] -VBUS2_V[site])*1.0e3f > 100.0f))	{
 				VBS1_F_V[site] = vr2[0];
				VBS1_VHYS_V[site] = (VBS1_R_V[site] - VBS1_F_V[site]);
 				flag[site] = 1;
 			}
		}
		// V5
		FPVI_VBUS1.Set(FV, vr2[1], FPVI10_10V, FPVI10_1A, RELAY_ON );
  	delay_ms(2);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && ((VBUS1_V[site] -VBUS2_V[site])*1.0e3f > 100.0f))	{
 				VBS1_F_V[site] = vr2[1];
				VBS1_VHYS_V[site] = (VBS1_R_V[site] - VBS1_F_V[site]);
 				flag[site] = 1;
 			}
		}

		// V6
		FPVI_VBUS1.Set(FV, vr2[2], FPVI10_10V, FPVI10_1A, RELAY_ON);
  	delay_ms(2);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
 			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if((flag[site] == 0) && ((VBUS1_V[site] -VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1_F_V[site] = vr2[2];
				VBS1_VHYS_V[site] = (VBS1_R_V[site] - VBS1_F_V[site]);
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING(L), VBUS1 *******************************************
	else {
		Tmpv = VBS1_R_V[0] + 0.03f;	// site1 alignment
 		for(Tmpv; Tmpv >= 1.5f;)	{
			FPVI_VBUS1.Set(FV, Tmpv, FPVI10_10V, FPVI10_1A, RELAY_ON);
  		delay_us(100);
			FPVI_VBUS1.MeasureVI(20, 10);
			FPVI_VBUS2.MeasureVI(20, 10);

  		for(site = 0; site < SITENUM; site++)	{
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

  			if((flag[site] == 0) && ((VBUS1_V[site] -VBUS2_V[site])*1.0e3f > 100.0f))	{
					VBS1_F_V[site] = Tmpv;
					VBS1_VHYS_V[site] = (VBS1_R_V[site] - VBS1_F_V[site]);
  				flag[site] = 1;
				}
  		}
  		if((flag[0] == 1) && (flag[1] == 1))
				break;
			if(Tmpv >= 2.8f) Tmpv += -10e-3f;
			else Tmpv += -5e-3f;
 		}
		FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	}
  // =====================================================================================
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_us(500);
  // =====================================================================================
	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FI, -0.5e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=E2h
  IIC_WRITE(SLVaddr, 0x03, 0xE2);
  IIC_READ(SLVaddr, 0x03, ReceiveData);
	FPVI_VBUS2.Set(FV, 2.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI_VBUS2.Set(FV, 2.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);

 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

 	StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
		if(sitesta[site])
 			flag[site] = 0;
  }
#ifdef NonShrink
	// ******************************************* GONOGO(H), VBUS2 *******************************************
	if (GONOGO)	{
		// V1
		FPVI_VBUS2.Set(FV, vr1[0], FPVI10_10V, FPVI10_1A, RELAY_ON);
  	delay_ms(2);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && (VBUS1_V[site] > 1.5f))	{
 				VBS2_R_V[site] = vr1[0];
 				flag[site] = 1;
 			}
		}
		// V2
		FPVI_VBUS2.Set(FV, vr1[1], FPVI10_10V, FPVI10_1A, RELAY_ON);
  	delay_ms(2);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && (VBUS1_V[site] > 1.5f))	{
 				VBS2_R_V[site] = vr1[1];
 				flag[site] = 1;
 			}
		}

		// V3
		FPVI_VBUS2.Set(FV, vr1[2], FPVI10_10V, FPVI10_1A, RELAY_ON);
  	delay_ms(2);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
 			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if((flag[site] == 0) && (VBUS1_V[site] > 1.5f))	{
				VBS2_R_V[site] = vr1[2];
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING(H), VBUS2 *******************************************
	else {
	  for(Tmpv = 2.78f; Tmpv <= 3.5f;)	{
			FPVI_VBUS2.Set(FV, Tmpv, FPVI10_10V, FPVI10_1A, RELAY_ON);
	  	delay_us(100);
		  FPVI_VBUS1.MeasureVI(20, 10);
		  FPVI_VBUS2.MeasureVI(20, 10);

			for(site = 0; site < SITENUM; site++)	{
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

				if((flag[site] == 0) && (VBUS1_V[site] > 1.5f))	{
					VBS2_R_V[site] = Tmpv;
	  			flag[site] = 1;
	  		}
	  	}
	  	if((flag[0] == 1) && (flag[1] == 1))
				break;
			if(Tmpv <= 2.98f) Tmpv += 10e-3f;
			else Tmpv += 5e-3f;
		}
	}
  // =====================================================================================
	FPVI_VBUS2.Set(FV, 4.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
  for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

 	StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO(H), VBUS2 *******************************************
	if (GONOGO)	{
		// V4
		FPVI_VBUS2.Set(FV, vr2[0], FPVI10_10V, FPVI10_1A, RELAY_ON);
  	delay_ms(2);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && ((VBUS2_V[site] -VBUS1_V[site])*1.0e3f > 100.0f))	{
 				VBS2_F_V[site] = vr2[0];
				VBS2_VHYS_V[site] = (VBS2_R_V[site] - VBS2_F_V[site]);
 				flag[site] = 1;
 			}
		}
		// V5
		FPVI_VBUS2.Set(FV, vr2[1], FPVI10_10V, FPVI10_1A, RELAY_ON);
  	delay_ms(2);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && ((VBUS2_V[site] -VBUS1_V[site])*1.0e3f > 100.0f))	{
 				VBS2_F_V[site] = vr2[1];
				VBS2_VHYS_V[site] = (VBS2_R_V[site] - VBS2_F_V[site]);
 				flag[site] = 1;
 			}
		}

		// V6
		FPVI_VBUS2.Set(FV, vr2[2], FPVI10_10V, FPVI10_1A, RELAY_ON);
  	delay_ms(2);
		FPVI_VBUS1.MeasureVI(20, 10);
		FPVI_VBUS2.MeasureVI(20, 10);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
 			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if((flag[site] == 0) && ((VBUS2_V[site] -VBUS1_V[site])*1.0e3f > 100.0f))	{
				VBS2_F_V[site] = vr2[2];
				VBS2_VHYS_V[site] = (VBS2_R_V[site] - VBS2_F_V[site]);
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING(L), VBUS2 *******************************************
	else {
		Tmpv = VBS2_R_V[0] + 0.03f;	// site1 alignment
 		for(Tmpv; Tmpv >= 1.5f;)	{
			FPVI_VBUS2.Set(FV, Tmpv, FPVI10_10V, FPVI10_1A, RELAY_ON);
  		delay_us(100);

		  FPVI_VBUS1.MeasureVI(20, 10);
		  FPVI_VBUS2.MeasureVI(20, 10);

  		for(site = 0; site < SITENUM; site++)	{
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

				if((flag[site] == 0) && ((VBUS2_V[site] - VBUS1_V[site])*1.0e3f > 100.0f))	{
  					VBS2_F_V[site] = Tmpv;
  	        VBS2_VHYS_V[site] = (VBS2_R_V[site] - VBS2_F_V[site]);
  					flag[site] = 1;
  			}
  		}
  		if((flag[0] == 1) && (flag[1] == 1))
				break;
			if(Tmpv >= 2.8f) Tmpv += -10e-3f;
			else Tmpv += -5e-3f;
 		}
	}
	FPVI_VBUS1.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
#endif
	// =====================================================================================
  pwrVI_RLY(0);
	pwr0V_SET();
  pwrOFF_SET();

	cbit128.SetOn(-1);
  for(site = 0; site < SITENUM; site++)	{
		VBS1_R		->SetTestResult(site, 0, VBS1_R_V[site]);
		VBS1_F		->SetTestResult(site, 0, VBS1_F_V[site]);
		VBS1_VHYS	->SetTestResult(site, 0, VBS1_VHYS_V[site]*1e3);
#ifdef NonShrink
		VBS2_R		->SetTestResult(site, 0, VBS2_R_V[site]);
		VBS2_F		->SetTestResult(site, 0, VBS2_F_V[site]);
		VBS2_VHYS	->SetTestResult(site, 0, VBS2_VHYS_V[site]*1e3);
#endif
	}
  return 0;
}
// test4 ***************************************** test4 *****************************************
DUT_API int EN_Threshold(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *ENR_BS1 = StsGetParam(funcindex,"ENR_BS1");
    CParam *ENF_BS1 = StsGetParam(funcindex,"ENF_BS1");
    CParam *ENR = StsGetParam(funcindex,"ENR");
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double ENR_BS1_V[SITENUM]	= {0.0f},	ENF_BS1_V[SITENUM]	= {0.0f};
  double ENR_R[SITENUM]			= {0.0f},	EN_C[SITENUM]				= {0.0f}, EN_V[SITENUM]	= {0.0f};
	double VBUS1_V[SITENUM]		= {0.0f},	VBUS2_V[SITENUM]		= {0.0f};
  int flag[SITENUM] = {0};
  BYTE sitesta[SITENUM] = {0};
	short GONOGO = ENR_BS1->GetConditionCurSelDouble("goPassFail");	// 0:Ramp	1:P/F
	double vr1[3] = { 1.04f, 1.12f, 1.15f };		// rising
	double vr2[3] = { 1.09f, 0.99f, 0.95f };		// falling


  cbit128.SetOn(VBUS1_Cap, VBUS2_Cap, VCC_Cap,
								VBUS1_Fpvi, VBUS2_Fpvi, EN_Fovi, IMON_1K, -1);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 1.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 1.0f, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 1.0f, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_us(500);

	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);

 	FOVI_EN.MeasureVI(20, 5);
  for(site = 0; site < SITENUM; site++)	{
		EN_C[site] = FOVI_EN.GetMeasResult(site, MIRET);
		EN_V[site] = FOVI_EN.GetMeasResult(site, MVRET);
		if (EN_C[site] > 0.0f)
			ENR_R[site] = (EN_V[site] /EN_C[site] ) * 1.0e-6f;
		else
			ENR_R[site] = 0.0f;
	}

  FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
  // ================================================================================================ EN On Threshold
	// ================================================================================================ EN On Threshold
	cbit128.SetOn(VBUS2_Cap, VBUS1_Cap, VCC_Cap,
								INTB_Fovi, ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi,
								EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, IMON_1K, -1);
	delay_ms(1);
	FOVI_ADDR.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);	// necessary
	FOVI_INTB.Set(FV, 5.0f, FOVI_10V, FOVI_100MA, RELAY_ON);
  FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_100MA, RELAY_ON);	// 240729-1, modify from 5v to 0.9v
																													// p8.0 set 0.9v
																													// p3.1 set 5.0v
	delay_ms(1);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_ms(1);

	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	delay_ms(2);
	FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);

  for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

 	StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }

	// ******************************************* GONOGO(H), VEN_ON *******************************************
	if (GONOGO)	{
		// V1
		FOVI_EN.Set(FV, vr1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
 		delay_ms(1);
		FPVI_VBUS2.MeasureVI(50, 5);

		for(site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && (VBUS2_V[site] > 4.1f))	{
 				ENR_BS1_V[site] = vr1[0];
				flag[site] = 1;
 			}
		}
		// V2
		FOVI_EN.Set(FV, vr1[1], FOVI_10V, FOVI_100MA, RELAY_ON);
 		delay_ms(1);
		FPVI_VBUS2.MeasureVI(50, 5);

		for(site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && (VBUS2_V[site] > 4.1f))	{
 				ENR_BS1_V[site] = vr1[1];
				flag[site] = 1;
 			}
		}
		// V3
		FOVI_EN.Set(FV, vr1[2], FOVI_10V, FOVI_100MA, RELAY_ON);
 		delay_ms(1);
		FPVI_VBUS2.MeasureVI(50, 5);

		for(site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
 			if((flag[site] == 0) && (VBUS2_V[site] > 4.1f))	{
 				ENR_BS1_V[site] = vr1[2];
				flag[site] = 1;
 			}
		}
	}
	// ******************************************* RAMPING(H), VEN_ON *******************************************
	else	{
		for(Tmpv = 0.9f; Tmpv <= 2.0f;)	{
			FOVI_EN.Set(FV, Tmpv, FOVI_10V, FOVI_100MA, RELAY_ON);
  		delay_us(100);

			FPVI_VBUS2.MeasureVI(50, 5);
  		for(site = 0; site < SITENUM; site++)	{
  			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  			if((flag[site] == 0) && (VBUS2_V[site] > 4.1f))	{
  					ENR_BS1_V[site] = Tmpv;
  					flag[site] = 1;
  			}
			}
			if((flag[0] == 1) && (flag[1] == 1))
				break;
			if(Tmpv < 0.98f)	Tmpv += 5e-3f;
			else	Tmpv += 2e-3f;
		}
  }
  // ================================================================================================ EN Off Threshold
	// ================================================================================================ EN Off Threshold
  FOVI_EN.Set(FV, 1.5f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
  FOVI_EN.Set(FV, 1.4f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(100);
  FOVI_EN.Set(FV, 1.3f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(100);
  FOVI_EN.Set(FV, 1.2f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(100);
  FOVI_EN.Set(FV, 1.1f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(100);

  for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
  for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }

	// ******************************************* GONOGO(L), VEN_OFF *******************************************
	if (GONOGO)	{
		// V4
		FOVI_EN.Set(FV, vr2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
 		delay_ms(1);
		FPVI_VBUS1.MeasureVI(20, 5);
		FPVI_VBUS2.MeasureVI(20, 5);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
 				ENF_BS1_V[site] = vr2[0];
				flag[site] = 1;
 			}
		}
		// V5
		FOVI_EN.Set(FV, vr2[1], FOVI_10V, FOVI_100MA, RELAY_ON);
 		delay_ms(1);
		FPVI_VBUS1.MeasureVI(20, 5);
		FPVI_VBUS2.MeasureVI(20, 5);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
 				ENF_BS1_V[site] = vr2[1];
				flag[site] = 1;
 			}
		}
		// V6
		FOVI_EN.Set(FV, vr2[2], FOVI_10V, FOVI_100MA, RELAY_ON);
 		delay_ms(1);
		FPVI_VBUS1.MeasureVI(20, 5);
		FPVI_VBUS2.MeasureVI(20, 5);

		for(site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
 				ENF_BS1_V[site] = vr2[2];
				flag[site] = 1;
 			}
		}
	}
	// ******************************************* RAMPING(L), VEN_OFF *******************************************
	else	{
		if (ENR_BS1_V[0] > ENR_BS1_V[1])
			Tmpv = ENR_BS1_V[0];	// site1 alignment
		else
			Tmpv = ENR_BS1_V[1];	// site2 alignment
		for(Tmpv; Tmpv >= 0.5f;)	{
			FOVI_EN.Set(FV, Tmpv, FOVI_10V, FOVI_10MA, RELAY_ON);
  		delay_us(100);
			FPVI_VBUS1.MeasureVI(20, 5);
			FPVI_VBUS2.MeasureVI(20, 5);
  		for(site = 0; site < SITENUM; site++)	{
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  			if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
  				ENF_BS1_V[site] = Tmpv;
  				flag[site] = 1;
  			}
  		}
  		if((flag[0] == 1) && (flag[1] == 1))
				break;
			if(Tmpv > 1.02f)	Tmpv += -5e-3f;
			else	Tmpv += -2e-3f;
		}
 	}
	pwr0V_SET();
	pwrOFF_SET();
	delay_ms(1);

	cbit128.SetOn(-1);
  for(site = 0; site < SITENUM; site++)	{
		ENR_BS1	->SetTestResult(site, 0, ENR_BS1_V[site]);
		ENF_BS1	->SetTestResult(site, 0, ENF_BS1_V[site]);
		ENR			->SetTestResult(site, 0, ENR_R[site]*1e3);
	}
  return 0;
}
// test5 ***************************************** test5 *****************************************
DUT_API int Leakage_Test(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *ILKG_33V_BS1 = StsGetParam(funcindex,"ILKG_33V_BS1");
    CParam *ILKG_33V_BS2 = StsGetParam(funcindex,"ILKG_33V_BS2");
    CParam *ILKG_39V5_BS1 = StsGetParam(funcindex,"ILKG_39V5_BS1"); // cancel, removed
    CParam *ILKG_39V5_BS2 = StsGetParam(funcindex,"ILKG_39V5_BS2"); // cancel, removed
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	double VBUS1_V[SITENUM]			={0.0f};
	double VBUS1_36V_C[SITENUM]	={0.0f},VBUS2_36V_C[SITENUM]	={0.0f};
	double VBUS1_39V5_C[SITENUM]={0.0f},VBUS2_39V5_C[SITENUM]	={0.0f};
	double vCHK[SITENUM] = { 0.0f };
 	int flag[SITENUM] = {0};
 	BYTE sitesta[SITENUM] = {0};

	cbit128.SetOn(VCC_Cap,
								VBUS1_Fpvi, VBUS2_Fpvi, MOUT_Fpvi, EN_Fovi, IMON_1K, -1);	// IMON1 and IMON2 series 1K to GND
	delay_ms(1);
	pwr0V_SET();
	// ======================================================================================== VMOUT=33.0V, BUS1 & BUS2 LEAK
	FPVI_MOUT.Set(FV, 33.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON, 5);
	delay_ms(2);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_1MA, RELAY_ON);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1MA, RELAY_ON);
	delay_ms(1);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_100UA, RELAY_ON);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_100UA, RELAY_ON);
	delay_ms(1);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10UA, RELAY_ON);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10UA, RELAY_ON);
	delay_ms(2);

	FPVI_MOUT.MeasureVI(100, 10);
	for (site = 0; site < SITENUM; site++)
		vCHK[site] = fabs(FPVI_MOUT.GetMeasResult(site, MVRET));

	if ((vCHK[0] > 32.8f)&&(vCHK[0] < 35.0f))	{
		FPVI_VBUS1.MeasureVI(100, 10);
		FPVI_VBUS2.MeasureVI(100, 10);
		for (site = 0; site < (SITENUM - 1); site++)	{
			VBUS1_36V_C[site] = fabs(FPVI_VBUS1.GetMeasResult(site, MIRET));
			VBUS2_36V_C[site] = fabs(FPVI_VBUS2.GetMeasResult(site, MIRET));
		}
	}
	if ((vCHK[1] > 32.8f)&&(vCHK[1] < 35.0f))	{
		FPVI_VBUS1.MeasureVI(100, 10);
		FPVI_VBUS2.MeasureVI(100, 10);
		for (site = 1; site < SITENUM; site++)	{
			VBUS1_36V_C[site] = fabs(FPVI_VBUS1.GetMeasResult(site, MIRET));
			VBUS2_36V_C[site] = fabs(FPVI_VBUS2.GetMeasResult(site, MIRET));
		}
	}
	FPVI_MOUT.Set(FV, 0.0f, FPVI10_50V, FPVI10_10MA, RELAY_ON, 3);
	delay_ms(1);
	// ========================================================================================
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);

	for(site = 0; site < SITENUM; site++)	{
		ILKG_33V_BS1	->SetTestResult(site, 0, VBUS1_36V_C[site]	*1.0e6f);
		ILKG_33V_BS2	->SetTestResult(site, 0, VBUS2_36V_C[site]	*1.0e6f);
	}
  return 0;
}
  // test7 ***************************************** test7 *****************************************
DUT_API int PowerOnDelay(short funcindex, LPCTSTR funclabel)	{
	//{{AFX_STS_PARAM_PROTOTYPES
    CParam *Tpwrdl_BS12 = StsGetParam(funcindex,"Tpwrdl_BS12");
    CParam *Tpwrdl_BS2 = StsGetParam(funcindex,"Tpwrdl_BS2");
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
  double TVBUS1_S[SITENUM] = {0.0f}, TVBUS2_S[SITENUM] = {0.0f};
 	int flag[SITENUM] = {0};
 	BYTE sitesta[SITENUM] = {0};

	cbit128.SetOn(VBUS1_Cap, VBUS2_Cap, MOUT_Cap, VCC_Cap,
								ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi,
								IMON_1K, VBUS1_QTMUU0A, VBUS2_QTMUU0B, QTMU_Sweep , -1);	// BUS2(A) -> BUS1(B)
	delay_ms(1);
	pwr0V_SET();
  // ============================================================================================ Tpwrdl_BS21
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	FPVI_VBUS2.Set(FV, 2.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FI, -0.05e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	
	// I2C
	// R=03h, D=E2h
	IIC_WRITE(SLVaddr, 0x03, 0xE2);
	delay_ms(2);

	qtmu0.ChannelSetup(QTMU_PLUS_CHA_START);
	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_PASS);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_PASS);
	qtmu0.SetStartTrigger(4.2f, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetStopTrigger(4.2f, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_DUAL_SOURCE);
	qtmu0.Connect();
	delay_ms(2);
	
	qtmu0.SetSinglePulseMeas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US);
	qtmu0.SetTimeOut(2);

	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	
	for(site = 0; site < SITENUM; site++ )  {
		qtmu0.SinglePlsMeas(site);
		TVBUS1_S[site]=qtmu0.GetMeasureResult(site);
 	}
	// ============================================================================================ Tpwrdl_BS12
  // ============================================================================================
	cbit128.SetOn(VBUS1_Cap, VBUS2_Cap, MOUT_Cap, VCC_Cap,
								ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi,
								IMON_1K, VBUS1_QTMUU0A, VBUS2_QTMUU0B, -1);	// BUS1(A) -> BUS2(B)
	delay_ms(1);
	pwr0V_SET();
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	FPVI_VBUS1.Set(FV, 2.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	// I2C
	// R=03h, D=C2h
	IIC_WRITE(SLVaddr, 0x03, 0xC2);
	delay_ms(2);

	qtmu0.ChannelSetup(QTMU_PLUS_CHA_START);
	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_PASS);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_PASS);
	qtmu0.SetStartTrigger(4.2f, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetStopTrigger(4.2f, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_DUAL_SOURCE);
	qtmu0.Connect();
	delay_ms(2);

	qtmu0.SetSinglePulseMeas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US);
	qtmu0.SetTimeOut(2);
	
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);

	for(site = 0; site < SITENUM; site++ )  {
		qtmu0.SinglePlsMeas(site);
		TVBUS2_S[site]=qtmu0.GetMeasureResult(site);
	}
	// ============================================================================================
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);
  
	for(site = 0; site < SITENUM; site++)	{
		Tpwrdl_BS12->SetTestResult(site, 0, TVBUS2_S[site]);
		Tpwrdl_BS2->SetTestResult(site, 0, TVBUS1_S[site]);
	}
  return 0;
}
// test8 ***************************************** test8 *****************************************
DUT_API int ReverseBlock(short funcindex, LPCTSTR funclabel)	{
	//{{AFX_STS_PARAM_PROTOTYPES
  CParam *VRCB_BS12_00 = StsGetParam(funcindex,"VRCB_BS12_00");
  CParam *VRCB_BS12_01 = StsGetParam(funcindex,"VRCB_BS12_01");
  CParam *VRCB_BS12_10 = StsGetParam(funcindex,"VRCB_BS12_10");		// cancel, removed
  CParam *VRCB_BS12_11 = StsGetParam(funcindex,"VRCB_BS12_11");		// cancel, removed
  CParam *VRCB_BS21_00 = StsGetParam(funcindex,"VRCB_BS21_00");
  CParam *VRCB_BS21_01 = StsGetParam(funcindex,"VRCB_BS21_01");
  CParam *VRCB_BS21_10 = StsGetParam(funcindex,"VRCB_BS21_10");		// cancel, removed
  CParam *VRCB_BS21_11 = StsGetParam(funcindex,"VRCB_BS21_11");		// cancel, removed
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double RCB00_V[SITENUM] = {0.0f}, RCB01_V[SITENUM] = {0.0f}, RCB10_V[SITENUM] = {0.0f}, RCB11_V[SITENUM] = {0.0f};
	double RCB00_VBUS2_V[SITENUM] = {0.0f}, RCB01_VBUS2_V[SITENUM] = {0.0f}, RCB10_VBUS2_V[SITENUM] = {0.0f}, RCB11_VBUS2_V[SITENUM] = {0.0f};
	double VBUS1_V[SITENUM] = {0.0f}, VBUS2_V[SITENUM] = {0.0f}, INTB_V[SITENUM] = {0.0f};
	double VBUS1_C[SITENUM] = { 0.0f }, VBUS2_C[SITENUM] = { 0.0f };
  int flag[SITENUM] = {0};
  BYTE sitesta[SITENUM] = {0};
	short GONOGO = VRCB_BS12_00->GetConditionCurSelDouble("goPassFail");	// 0:Ramp	1:P/F
	double ramping_step = 3e-3f;
	double v1[3] = { 3.285, 3.332, 3.335 }, v2[3] = { 3.265/*3.335*/, 3.357, 3.36 };
	
	pwr0V_SET();
	////FPVI_VBUS2.Set  (FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_OFF);
	////delay_ms(1);
  // ========================================================================
	cbit128.SetOn(VBUS1_Cap, MOUT_Cap, VBUS2_Cap, VCC_Cap, 
								IMON_1K, INTB_Fovi, ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, -1);
	delay_ms(1);
  // INTB = 5V
	FOVI_INTB.Set(FV, 5.0f, FOVI_10V, FOVI_100UA, RELAY_ON);
  // EN = 2V
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
  // BUS1 = 5V
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
  // BUS1 = 3.3V
	FPVI_VBUS1.Set(FV, 3.3f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
  // BUS2 = 3.31V
	FPVI_VBUS2.Set(FV, 3.29f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	// *************************************************************************************************************
	// *************************************************************************************************************
	// *************************************************************************************************************
	// ======================================================================== BS12_00
	// S=0x90, R=0x03, D=0xC2/0xC8/0xD2/0xD8
  // I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);  // BS12_00
  for(site = 0; site < SITENUM; site++)
      flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
  for(site = 0; site < SITENUM; site++) {
  	if(sitesta[site])
 		  flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FPVI_VBUS2.Set(FV, v1[0], FPVI10_10V, FPVI10_1A, RELAY_ON, 5);
		delay_ms(20);
		FOVI_INTB.MeasureVI(10, 10);
		//FPVI_VBUS1.MeasureVI(10, 10);
		//FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
			INTB_V[site] = FOVI_INTB.GetMeasResult(site, MVRET);
			//VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			//VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
				//RCB00_V[site] = (VBUS2_V[site] - VBUS1_V[site])*1.0e3f;
				RCB00_V[site] = (3.3f - v1[0])*1.0e3f;
				flag[site] = 1;
			}
		}
		FPVI_VBUS2.Set(FV, v1[1], FPVI10_10V, FPVI10_1A, RELAY_ON, 5);
		delay_ms(20);
		FOVI_INTB.MeasureVI(10, 10);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
			INTB_V[site]  = FOVI_INTB.GetMeasResult(site, MVRET);
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
	  	if((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
				RCB00_V[site] = (VBUS2_V[site] - VBUS1_V[site])*1.0e3f;
	  			flag[site] = 1;
	  	}
		}

		FPVI_VBUS2.Set(FV, v1[2], FPVI10_10V, FPVI10_1A, RELAY_ON, 5);
		delay_ms(20);
		FOVI_INTB.MeasureVI(10, 10);
		//FPVI_VBUS1.MeasureVI(10, 10);
		//FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
			INTB_V[site]  = FOVI_INTB.GetMeasResult(site, MVRET);
			//VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			//VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
	  	if((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
				//RCB00_V[site] = (VBUS2_V[site] - VBUS1_V[site])*1.0e3f;
				RCB00_V[site] = (v1[2] - 3.3f)*1.0e3f;
	  			flag[site] = 1;
	  	}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
	  for(Tmpv = 3.29f; Tmpv <= 3.336/*3.5f*/;)  {
		  FPVI_VBUS2.Set(FV, Tmpv , FPVI10_10V, FPVI10_10A, RELAY_ON);
			delay_ms(10);// delay_ms(2);delay_us(2300)

			FPVI_VBUS2.MeasureVI(10, 10);
			FPVI_VBUS1.MeasureVI(10, 10);
			FOVI_INTB.MeasureVI(50, 10);
	  	for(site = 0; site < SITENUM; site++) {
	      INTB_V[site]  = FOVI_INTB.GetMeasResult(site, MVRET);
	  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

	  		if((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
					RCB00_V[site] = (VBUS2_V[site] - VBUS1_V[site])*1.0e3f;
	  				flag[site] = 1;
	  		}
	  	}
	  	if((flag[0] == 1) && (flag[1] == 1))
	      break;
	  	Tmpv += ramping_step;
	  }
	}
	// ======================================================================== BS12_01
	pwr0V_SET();
	// INTB = 5V
	FOVI_INTB.Set(FV, 5.0f, FOVI_10V, FOVI_1UA, RELAY_ON);
	// EN = 2V
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	// BUS1 = 3.3V
	FPVI_VBUS1.Set(FV, 3.3f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	// BUS2 = 3.31V
	FPVI_VBUS2.Set(FV, 3.29f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=C8h
	IIC_WRITE(SLVaddr, 0x03, 0xC8);  // BS12_01
	for (site = 0; site < SITENUM; site++)
		flag[site] = 1;

	StsGetSiteStatus(sitesta, SITENUM);
	for (site = 0; site < SITENUM; site++) {
		if (sitesta[site])
			flag[site] = 0;
	}

	// ******************************************* GONOGO *******************************************
	//if (GONOGO)	{
	//	FPVI_VBUS2.Set(FV, v2[0], FPVI10_10V, FPVI10_1A, RELAY_ON, 5);
	//	//delay_ms(20);
	//	FOVI_INTB.MeasureVI(50, 10);
	//	//FPVI_VBUS1.MeasureVI(10, 10);
	//	//FPVI_VBUS2.MeasureVI(10, 10);
	//	for (site = 0; site < SITENUM; site++)	{
	//		INTB_V[site]  = FOVI_INTB.GetMeasResult(site, MVRET);
	//		//VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	//		//VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
	//  	if((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
	//			//RCB01_V[site] = (VBUS2_V[site] - VBUS1_V[site])*1.0e3f;
	//			RCB01_V[site] = (3.3f - v2[0])*1.0e3f;
	//  			flag[site] = 1;
	//  	}
	//	}

	//	FPVI_VBUS2.Set(FV, v2[1], FPVI10_10V, FPVI10_1A, RELAY_ON, 5);
	//	//delay_ms(20);
	//	FOVI_INTB.MeasureVI(50, 10);
	//	FPVI_VBUS1.MeasureVI(10, 10);
	//	FPVI_VBUS2.MeasureVI(10, 10);
	//	for (site = 0; site < SITENUM; site++)	{
	//		INTB_V[site]  = FOVI_INTB.GetMeasResult(site, MVRET);
	//		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	//		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
	//  	if((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
	//			RCB01_V[site] = (VBUS2_V[site] - VBUS1_V[site])*1.0e3f;
	//  			flag[site] = 1;
	//  	}
	//	}

	//	FPVI_VBUS2.Set(FV, v2[2], FPVI10_10V, FPVI10_1A, RELAY_ON, 5);
	//	//delay_ms(20);
	//	FOVI_INTB.MeasureVI(50, 10);
	//	//FPVI_VBUS1.MeasureVI(10, 10);
	//	//FPVI_VBUS2.MeasureVI(10, 10);
	//	for (site = 0; site < SITENUM; site++)	{
	//		INTB_V[site]  = FOVI_INTB.GetMeasResult(site, MVRET);
	//		//VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	//		//VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
	//  	if((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
	//			RCB01_V[site] = (v2[2] - 3.3f)*1.0e3f;
	//  			flag[site] = 1;
	//  	}
	//	}
	//}
	// ******************************************* RAMPING *******************************************
	//else	{
		for (Tmpv = 3.29f; Tmpv <= 3.36f/*3.5*/;)  {
			FPVI_VBUS2.Set(FV, Tmpv, FPVI10_10V, FPVI10_10A, RELAY_ON);
			delay_ms(2);// delay_ms(2);//5  delay_us(2500)

			FPVI_VBUS2.MeasureVI(10, 10);
			FPVI_VBUS1.MeasureVI(10, 10);
			FOVI_INTB.MeasureVI(50, 10);
			for (site = 0; site < SITENUM; site++) {
				INTB_V[site] = FOVI_INTB.GetMeasResult(site, MVRET);
				VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
				if ((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
					RCB01_V[site] = (VBUS2_V[site] - VBUS1_V[site])*1.0e3f;
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	//}
	// *************************************************************************************************************
	// *************************************************************************************************************
	// *************************************************************************************************************
	// S=0x90, R=0x03, D=0xE0/0xE8/0xF0/0xF8
  // ======================================================================== BS21_00
	test7_RST();
	// R=03h, D=E2h
  IIC_WRITE(SLVaddr, 0x03, 0xE2);  // B21_00

  for(site = 0; site < SITENUM; site++)
    flag[site] = 1;
  StsGetSiteStatus(sitesta, SITENUM);

  for(site = 0; site < SITENUM; site++) {
  	if(sitesta[site])
 			flag[site] = 0;
 	}
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FPVI_VBUS1.Set(FV, v1[0], FPVI10_10V, FPVI10_10A, RELAY_ON, 5);
		delay_ms(20);
		FOVI_INTB.MeasureVI(50, 10);
		//FPVI_VBUS1.MeasureVI(10, 10);
		//FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
			INTB_V[site] = FOVI_INTB.GetMeasResult(site, MVRET);
			//VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			//VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
				//RCB00_VBUS2_V[site] = (VBUS1_V[site] - VBUS2_V[site])*1.0e3f;
				RCB00_VBUS2_V[site] = (3.3f - v1[0])*1.0e3f;
				flag[site] = 1;
			}
		}
		FPVI_VBUS1.Set(FV, v1[1], FPVI10_10V, FPVI10_10A, RELAY_ON, 5);
		delay_ms(20);
		FOVI_INTB.MeasureVI(50, 10);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
			INTB_V[site] = FOVI_INTB.GetMeasResult(site, MVRET);
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
				RCB00_VBUS2_V[site] = (VBUS1_V[site] - VBUS2_V[site])*1.0e3f;
				flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v1[2], FPVI10_10V, FPVI10_10A, RELAY_ON, 5);
		delay_ms(20);
		FOVI_INTB.MeasureVI(50, 10);
		//FPVI_VBUS1.MeasureVI(10, 10);
		//FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
			INTB_V[site] = FOVI_INTB.GetMeasResult(site, MVRET);
			//VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			//VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
				//RCB00_VBUS2_V[site] = (VBUS1_V[site] - VBUS2_V[site])*1.0e3f;
				RCB00_VBUS2_V[site] = (v1[2] - 3.3f)*1.0e3f;
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for (Tmpv = 3.29f; Tmpv <= 3.335/*3.5f*/;)  {
			FPVI_VBUS1.Set(FV, Tmpv, FPVI10_10V, FPVI10_10A, RELAY_ON);
			delay_ms(2);// delay_ms(2);//8//1700

			FPVI_VBUS1.MeasureVI(20, 10);
			FPVI_VBUS2.MeasureVI(20, 10);
			FOVI_INTB.MeasureVI(50, 10);
			for (site = 0; site < SITENUM; site++) {
				INTB_V[site] = FOVI_INTB.GetMeasResult(site, MVRET);
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
				VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
				if ((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
					RCB00_VBUS2_V[site] = (VBUS1_V[site] - VBUS2_V[site])*1.0e3f;
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	}
	// ======================================================================== BS21_01
	test7_RST();
	// R=03h, D=E0h
	IIC_WRITE(SLVaddr, 0x03, 0xE8);  // B21_01

	for (site = 0; site < SITENUM; site++)
		flag[site] = 1;
	StsGetSiteStatus(sitesta, SITENUM);

	for (site = 0; site < SITENUM; site++) {
		if (sitesta[site])
			flag[site] = 0;
	}
	// ******************************************* GONOGO *******************************************
	//if (GONOGO)	{
	//}
	//// ******************************************* RAMPING *******************************************
	//else	{
		for (Tmpv = 3.29f; Tmpv <= 3.36f/*3.5f*/;)  {
			FPVI_VBUS1.Set(FV, Tmpv, FPVI10_10V, FPVI10_10A, RELAY_ON, 1);
			 delay_ms(10);//5

			FPVI_VBUS1.MeasureVI(10, 10);
			FPVI_VBUS2.MeasureVI(10, 10);
			FOVI_INTB.MeasureVI(50, 10);
				for (site = 0; site < SITENUM; site++) {
				INTB_V[site] = FOVI_INTB.GetMeasResult(site, MVRET);
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
				VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

				if ((flag[site] == 0) && (INTB_V[site] < 1.0f))  {
					RCB01_VBUS2_V[site] = (VBUS1_V[site] - VBUS2_V[site])*1.0e3f;
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	//}
  // ========================================================================
  // ========================================================================
#ifdef NonShrink
		FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_OFF);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_OFF);
	delay_us(500);
  // ========================================================================
#endif
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);

  for(site = 0; site < SITENUM; site++) {
	 	VRCB_BS12_00->SetTestResult(site, 0, RCB00_V[site]);
		VRCB_BS12_01->SetTestResult(site, 0, RCB01_V[site]);
		VRCB_BS21_00->SetTestResult(site, 0, RCB00_VBUS2_V[site]);
		VRCB_BS21_01->SetTestResult(site, 0, RCB01_VBUS2_V[site]);
	}
  return 0;
}
// test9 ***************************************** test9 *****************************************
DUT_API int RB_ResponseTime(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *RCBDL_SET_00 = StsGetParam(funcindex,"RCBDL_SET_00");
    CParam *RCBDL_SET_01 = StsGetParam(funcindex,"RCBDL_SET_01");   // cancel, removed
    CParam *RCBDL_SET_10 = StsGetParam(funcindex,"RCBDL_SET_10");   // cancel, removed
    CParam *RCBDL_SET_11 = StsGetParam(funcindex,"RCBDL_SET_11");   // cancel, removed
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	double rCB_set00[SITENUM]	= { 0.0f }, rCB_set01[SITENUM]	={ 0.0f }, rCB_set11[SITENUM]	={ 0.0f }, rCB_set10[SITENUM]	={ 0.0f };
	int flag[SITENUM] = { 0 }, i1 = 0;
 	BYTE sitesta[SITENUM] = { 0 };
	double VBUS1_RES_I[SITENUM][2000] = {{ 0.0f },{ 0.0f }}, GetT1_T2[SITENUM] = { 0 };

	cbit128.SetOn(VBUS1_Cap, VBUS2_Cap, MOUT_Cap, VCC_Cap,
								ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi,
								EN_MOUT_Short, INTB_100K_Fovi, IMON_1K, VBUS1_QTMUU0A, -1);		// BUS1(A)
	delay_ms(1);
	// ============================================================
	FOVI_ADDR.Set(FV, 0.0f, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI_INTB_100K.Set(FV, 5.0f, FOVI_10V, FOVI_100MA, RELAY_ON);

	for (site = 0; site < SITENUM; site++)
		flag[site] = 1;

	StsGetSiteStatus(sitesta, SITENUM);
	for (site = 0; site < SITENUM; site++)	{
		if (sitesta[site])
			flag[site] = 0;
	}
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_100MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	// VBUS1=5V
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_ms(1);

	// I2C
	// R=03h, D=C0h
	IIC_WRITE(SLVaddr, 0x03, 0xC0);
	delay_ms(2);
	// R=06h, D=00h(10us), 01h(100ns), 02h(50us), 03h(200us), Reg0x6[1:0]
	IIC_WRITE(SLVaddr, 0x06, 0x00);
	delay_ms(2);

	// A TO B
	qtmu0.ChannelSetup(QTMU_PLUS_CHA_START);
	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz/*QTMU_PLUS_FILTER_PASS*/);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz/*QTMU_PLUS_FILTER_PASS*/);

	// attention level setting
	qtmu0.SetStartTrigger(4.21f, QTMU_PLUS_NEG_SLOPE);
	qtmu0.SetStopTrigger(4.13f, QTMU_PLUS_NEG_SLOPE);

	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();
	delay_ms(2);

	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_ms(2);
	FPVI_VBUS1.Set(FI, -0.01e-3f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	
	FPVI_VBUS1.Set(FV, 4.0f, FPVI10_10V, FPVI10_10A, RELAY_OFF);
	delay_ms(1);

	qtmu0.SetSinglePulseMeas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US);
	qtmu0.SetTimeOut(50);
	FPVI_VBUS1.Set(FI, -2.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);

	for (site = 0; site < SITENUM; site++)  {
		qtmu0.SinglePlsMeas(site);
		rCB_set00[site] = qtmu0.GetMeasureResult(site);
	}

	FPVI_VBUS1.Set(FI, -100e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI_VBUS1.Set(FI, -0e-3f, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_ms(1);

	pwr0V_SET();
	pwrOFF_SET();

	for (site = 0; site < SITENUM; site++)
		RCBDL_SET_00->SetTestResult(site, 0, rCB_set00[site] + float(-0));
	cbit128.SetOn(-1);

  return 0;
}
// test10 ***************************************** test10 *****************************************
DUT_API int VBUS_DisChargeR(short funcindex, LPCTSTR funclabel)	{
	//{{AFX_STS_PARAM_PROTOTYPES
    CParam *RDSCBS2_00 = StsGetParam(funcindex,"RDSCBS2_00");   // removed604
    CParam *RDSCBS2_01 = StsGetParam(funcindex,"RDSCBS2_01");   // removed604
    CParam *RDSCBS2_10 = StsGetParam(funcindex,"RDSCBS2_10");   // removed604
    CParam *RDSCBS2_11 = StsGetParam(funcindex,"RDSCBS2_11");   // removed604
    CParam *RDSCBS1_00 = StsGetParam(funcindex,"RDSCBS1_00");
    CParam *RDSCBS1_01 = StsGetParam(funcindex,"RDSCBS1_01");
    CParam *RDSCBS1_10 = StsGetParam(funcindex,"RDSCBS1_10");
    CParam *RDSCBS1_11 = StsGetParam(funcindex,"RDSCBS1_11");   // removed604
  //}}AFX_STS_PARAM_PROTOTYPES
	unsigned char ReceiveData[SITENUM] = {0};
	double VBUS1_V[SITENUM] = {0.0f}, VBUS2_V[SITENUM] = {0.0f};
	double VBUS1_C[SITENUM] ={ 0.0f}, VBUS2_C[SITENUM] = {0.0f};
	double RDSCBS2_00_R[SITENUM]	= {0.0f}, RDSCBS2_01_R[SITENUM]	= {0.0f}, RDSCBS2_10_R[SITENUM]	= {0.0f}, RDSCBS2_11_R[SITENUM]	= {0.0f};
	double RDSCBS1_00_R[SITENUM]	= {0.0f}, RDSCBS1_01_R[SITENUM]	= {0.0f}, RDSCBS1_10_R[SITENUM]	= {0.0f}, RDSCBS1_11_R[SITENUM]	= {0.0f};
  int flag[SITENUM] = {0};
  BYTE sitesta[SITENUM] = {0};

	cbit128.SetOn(VBUS1_Fpvi, VBUS2_Fpvi, EN_Fovi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, ADDR_Fovi, IMON_1K, -1);
	delay_ms(1);
	pwr0V_SET();
#ifdef NonShrink
  // ===================================================================================== BUS2 DISCHARGE RESISTANCE: 00
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=05h, D=30h
  IIC_WRITE(SLVaddr, 0x05, 0x30);

	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI_VBUS2.MeasureVI(20, 5);
 	for(site = 0; site < SITENUM; site++)	{
		VBUS2_C[site] = FPVI_VBUS2.GetMeasResult(site, MIRET);
  	VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

		if (VBUS2_C[site] > 0.0f)
			RDSCBS2_00_R[site] = VBUS2_V[site] / (VBUS2_C[site] + 0.1e-12f);
		else
			RDSCBS2_00_R[site] = 0.0f;
	}
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	// ===================================================================================== BUS2 DISCHARGE RESISTANCE: 01
	// I2C
	// R=05h, D=34h
  IIC_WRITE(SLVaddr, 0x05, 0x34);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI_VBUS2.MeasureVI(20, 5);
  for(site = 0; site < SITENUM; site++)  	{
		VBUS2_C[site] = FPVI_VBUS2.GetMeasResult(site, MIRET);
  	VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
		if (VBUS2_C[site] > 0.0f)
			RDSCBS2_01_R[site] = VBUS2_V[site] / (VBUS2_C[site] + 0.1e-12f);
		else
			RDSCBS2_01_R[site] = 0.0f;
	}
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	// ===================================================================================== BUS2 DISCHARGE RESISTANCE: 10
	// I2C
	// R=05h, D=38h
  IIC_WRITE(SLVaddr, 0x05, 0x38);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI_VBUS2.MeasureVI(20, 5);
  for(site = 0; site < SITENUM; site++)	{
		VBUS2_C[site] = FPVI_VBUS2.GetMeasResult(site, MIRET);
  	VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

		if (VBUS2_C[site] > 0.0f)
			RDSCBS2_10_R[site] = VBUS2_V[site] / (VBUS2_C[site] + 0.1e-12f);
		else
      RDSCBS2_10_R[site] = 0.0f;
	}
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	// ===================================================================================== BUS2 DISCHARGE RESISTANCE: 11
	// I2C
	// R=05h, D=3Ch
	IIC_WRITE(SLVaddr, 0x05, 0x3C);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI_VBUS2.MeasureVI(50, 10);
  for(site = 0; site < SITENUM; site++)	{
		VBUS2_C[site] = FPVI_VBUS2.GetMeasResult(site, MIRET);
  	VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

		if (VBUS2_C[site] > 0.0f)
			RDSCBS2_11_R[site] = VBUS2_V[site] / (VBUS2_C[site] + 0.1e-12f);
		else
			RDSCBS2_11_R[site] = 0.0f;
	}
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	delay_us(500);
#endif
  // ===================================================================================== BUS1 DISCHARGE RESISTANCE: 00
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=E2h
  IIC_WRITE(SLVaddr, 0x03, 0xE2);
	// R=05h, D=30h
  IIC_WRITE(SLVaddr, 0x05, 0x30);

	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI_VBUS1.MeasureVI(20, 10);
	for(site = 0; site < SITENUM; site++)	{
		VBUS1_C[site] = FPVI_VBUS1.GetMeasResult(site, MIRET);
  	VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

		if (VBUS1_C[site] > 0.0f)
			RDSCBS1_00_R[site] = VBUS1_V[site] / (VBUS1_C[site] + 0.1e-12f);
		else
			RDSCBS1_00_R[site] = 0.0f;
	}
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	// ===================================================================================== BUS1 DISCHARGE RESISTANCE: 01
	// I2C
	// R=05h, D=34h
	IIC_WRITE(SLVaddr, 0x05, 0x34);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI_VBUS1.MeasureVI(20, 10);
	for(site = 0; site < SITENUM; site++)	{
		VBUS1_C[site] = FPVI_VBUS1.GetMeasResult(site, MIRET);
  	VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

		if (VBUS1_C[site] > 0.0f)
			RDSCBS1_01_R[site] = VBUS1_V[site] / (VBUS1_C[site] + 0.1e-12f);
		else
      RDSCBS1_01_R[site] = 0.0f;
	}
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	// ===================================================================================== BUS1 DISCHARGE RESISTANCE: 10
	// I2C
	// R=05h, D=38h
	IIC_WRITE(SLVaddr, 0x05, 0x38);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI_VBUS1.MeasureVI(50, 10);
 	for(site = 0; site < SITENUM; site++)	{
		VBUS1_C[site] = FPVI_VBUS1.GetMeasResult(site, MIRET);
  	VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

		if (VBUS1_C[site] > 0.0f)
			RDSCBS1_10_R[site] = VBUS1_V[site] / (VBUS1_C[site] + 0.1e-12f);
		else
      RDSCBS1_10_R[site] = 0.0f;
	}
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);//10
#ifdef NonShrink
	// ===================================================================================== BUS1 DISCHARGE RESISTANCE: 11
	// I2C
	// R=05h, D=3Ch
	IIC_WRITE(SLVaddr, 0x05, 0x3C);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI_VBUS1.MeasureVI(20, 10);
  for(site = 0; site < SITENUM; site++)	{
		VBUS1_C[site] = FPVI_VBUS1.GetMeasResult(site, MIRET);
  	VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

		if (VBUS1_C[site] > 0.0f)
			RDSCBS1_11_R[site] = VBUS1_V[site] / (VBUS1_C[site] + 0.1e-12f);
		else
      RDSCBS1_11_R[site] = 0.0f;
	}
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	delay_us(500);
#endif
	// =====================================================================================
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);

  for(site = 0; site < SITENUM; site++)	{
#ifdef NonShrink
		RDSCBS2_00->SetTestResult(site, 0, RDSCBS2_00_R[site]);
		RDSCBS2_01->SetTestResult(site, 0, RDSCBS2_01_R[site]);
		RDSCBS2_10->SetTestResult(site, 0, RDSCBS2_10_R[site]);
		RDSCBS2_11->SetTestResult(site, 0, RDSCBS2_11_R[site]*1e-6);	// HIGH IMPEDANCE
 		RDSCBS1_11->SetTestResult(site, 0, RDSCBS1_11_R[site]*1e-6);	// HIGH IMPEDANCE
#endif
		RDSCBS1_00->SetTestResult(site, 0, RDSCBS1_00_R[site]);
		RDSCBS1_01->SetTestResult(site, 0, RDSCBS1_01_R[site]);
		RDSCBS1_10->SetTestResult(site, 0, RDSCBS1_10_R[site]);
	}
  return 0;
}
// test11 ***************************************** test11 *****************************************
DUT_API int VBUS_ActiveDisT(short funcindex, LPCTSTR funclabel)	{
	//{{AFX_STS_PARAM_PROTOTYPES
    CParam *TDSC_00 = StsGetParam(funcindex,"TDSC_00");
    CParam *TDSC_00X = StsGetParam(funcindex,"TDSC_00X");
    CParam *TDSC_10 = StsGetParam(funcindex,"TDSC_10");     // cancel, removed
    CParam *TDSC_11 = StsGetParam(funcindex,"TDSC_11");     // cancel, removed
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double VBUS1_V[SITENUM]		= {0.0f}, VBUS2_V[SITENUM]		= {0.0f}, INTB_V[SITENUM]			= {0.0f};
	double TDSC_00_T[SITENUM]	= {0.0f}, TDSC_01_T[SITENUM]	= {0.0f}, TDSC_10_T[SITENUM]	= {0.0f}, TDSC_11_T[SITENUM] = {0.0f};
  int flag[SITENUM] = {0};
  BYTE sitesta[SITENUM] = {0};

	cbit128.SetOn(VBUS1_Cap, VBUS2_Cap, MOUT_Cap, VCC_Cap,
								ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, FRSEN_Fovi, INTB_100K_Fovi,
								INTB_QTMUU0A, IMON_1K, -1);
	delay_ms(1);
  // =================================================================================
  FOVI_INTB_100K.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);

	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// TM latched
	FOVI_ADDR.Set(FV, 1.5f, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI_FRSEN.Set(FV, 0.0f, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_us(500);
	setupTM(5.0f, 5.3f, 5.0f);

	// TM2
	TM_SEL(0.0f, 1.5f);
	delay_us(500);
	// =============================================================================== tDSC 00
	qtmu0.Init();
	// I2C
	// R=05h, D=00h, Reg0x5[5:4]
  IIC_WRITE(SLVaddr, 0x05, 0x00);	// default 2'b00
	delay_ms(2);

	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, /*QTMU_PLUS_FILTER_PASS*/QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, /*QTMU_PLUS_FILTER_PASS*/QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStartTrigger(3.5f,QTMU_PLUS_POS_SLOPE);
	qtmu0.SetStopTrigger(3.5f,QTMU_PLUS_NEG_SLOPE);
  qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();
	delay_ms(1);

	for(site = 0; site < SITENUM; site++)  {
    qtmu0.SetSinglePulseMeas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, site);
    qtmu0.SetTimeOut(100);
    qtmu0.SinglePlsMeas(site);
		TDSC_00_T[site]=qtmu0.GetMeasureResult(site)*1.0e-3f;
 	}
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// =================================================================================
	pwr0V_SET();
	pwrOFF_SET();

	cbit128.SetOn(-1);
  for(site = 0; site < SITENUM; site++)	{
		TDSC_00->SetTestResult(site, 0, TDSC_00_T[site]);
		TDSC_00X->SetTestResult(site, 0, TDSC_00_T[site]*7.4);
	}
  return 0;
}
// test12 ***************************************** test12 *****************************************
DUT_API int OVP_Threshold(short funcindex, LPCTSTR funclabel)	{
	//{{AFX_STS_PARAM_PROTOTYPES
    CParam *VBS1OV_000 = StsGetParam(funcindex,"VBS1OV_000");
    CParam *VBS1OV_001 = StsGetParam(funcindex,"VBS1OV_001");   // removed604
    CParam *VBS1OV_010 = StsGetParam(funcindex,"VBS1OV_010");   // removed604
    CParam *VBS1OV_011 = StsGetParam(funcindex,"VBS1OV_011");   // removed604
    CParam *VBS1OV_100 = StsGetParam(funcindex,"VBS1OV_100");   // removed604
    CParam *VBS1OV_101 = StsGetParam(funcindex,"VBS1OV_101");
    CParam *VBS1OV_110 = StsGetParam(funcindex,"VBS1OV_110");   // cancel, removed
    CParam *VBS1OV_111 = StsGetParam(funcindex,"VBS1OV_111");   // cancel, removed
    CParam *V120 = StsGetParam(funcindex,"V120");
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double VBS1OV_000_V[SITENUM] = {0.0f}, VBS1OV_001_V[SITENUM] = {0.0f}, VBS1OV_010_V[SITENUM] = {0.0f}, VBS1OV_011_V[SITENUM] = {0.0f};
	double VBS1OV_100_V[SITENUM] = {0.0f}, VBS1OV_101_V[SITENUM] = {0.0f}, VBS1OV_110_V[SITENUM] = {0.0f}, VBS1OV_111_V[SITENUM] = {0.0f};
  double V120_V[SITENUM]	= {0.0f};
	double VBUS1_V[SITENUM]	= {0.0f}, VBUS2_V[SITENUM]	= {0.0f};
	double VBUS1_C[SITENUM] = {0.0f}, VBUS2_C[SITENUM]	= {0.0f};
	int flag[SITENUM] = {0};
  BYTE sitesta[SITENUM] = {0};
	short GONOGO = VBS1OV_000->GetConditionCurSelDouble("goPassFail");	// 0:Ramp	1:P/F
	double ramping_step = 10e-3f;
	double v1[3] = { 5.7, 6.06, 6.29 }, v2[3] = { 10.4, 11.0, 11.19 }, v3[3] = { 13.8, 14.65, 14.99 };
	double v4[3] = { 17.0, 18.16, 18.99 }, v5[3] = { 23.0, 24.33, 24.99 }, v6[3] = { 32.2, 34.1, 34.99 };

	cbit128.SetOn(VBUS1_Cap, VBUS2_Cap, MOUT_Cap, VCC_Cap,
								ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, IMON_1K, -1);
	delay_ms(1);
	pwr0V_SET();
	FPVI_MOUT.Set	(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_ms(1);
  // ======================================================================================== VBS10V: 000
	FOVI_INTB.Set(FV, 5.0f, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	FPVI_VBUS1.Set(FV, 5.75f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);

 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }

	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FPVI_VBUS1.Set(FV, v1[0], FPVI10_10V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_000_V[site] = v1[0];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v1[1], FPVI10_10V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_000_V[site] = v1[1];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v1[2], FPVI10_10V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_000_V[site] = v1[2];
  			flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for(Tmpv = 5.65f; Tmpv <= 6.31f;)	{
			FPVI_VBUS1.Set(FV, Tmpv, FPVI10_10V, FPVI10_1A, RELAY_ON);
  		delay_us(100);

			FPVI_VBUS1.MeasureVI(10, 10);
			FPVI_VBUS2.MeasureVI(10, 10);
			for(site = 0; site < SITENUM; site++)	{
  			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

  			if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
					VBS1OV_000_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  				flag[site] = 1;
  			}
  		}
			if((flag[0] == 1) && (flag[1] == 1))
				break;
  		Tmpv += ramping_step;
		}
	}
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);
  // ======================================================================================== VBS10V: 001
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=88h
  IIC_WRITE(SLVaddr, 0x04, 0x88);

	FPVI_VBUS1.Set(FV, 10.5f, FPVI10_20V, FPVI10_1A, RELAY_ON, 1);
	delay_us(500);
 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 		flag[site] = 0;
  }
#ifdef NonShrink
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FPVI_VBUS1.Set(FV, v2[0], FPVI10_20V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_001_V[site] = v2[0];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v2[1], FPVI10_20V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_001_V[site] = v2[1];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v2[2], FPVI10_20V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_001_V[site] = v2[2];
  			flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for(Tmpv = 10.35f; Tmpv <= 11.21f;)	{
			FPVI_VBUS1.Set(FV, Tmpv, FPVI10_20V, FPVI10_1A, RELAY_ON);
  		delay_us(100);

		  FPVI_VBUS1.MeasureVI(10, 10);
			FPVI_VBUS2.MeasureVI(10, 10);
  		for(site = 0; site < SITENUM; site++)	{
  			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

				if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
					VBS1OV_001_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  				flag[site] = 1;
  			}
  		}
  		if((flag[0] == 1) && (flag[1] == 1))
				break;
  		Tmpv += ramping_step;
 		}
	}
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);

  // ======================================================================================== VBS10V: 010
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
	IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=90h
  IIC_WRITE(SLVaddr, 0x04, 0x90);

	FPVI_VBUS1.Set(FV, 14.0f, FPVI10_20V, FPVI10_1A, RELAY_ON, 1);
	delay_us(500);
  for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FPVI_VBUS1.Set(FV, v3[0], FPVI10_20V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_010_V[site] = v3[0];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v3[1], FPVI10_20V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_010_V[site] = v3[1];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v3[2], FPVI10_20V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_010_V[site] = v3[2];
  			flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for(Tmpv = 13.75f; Tmpv <= 15.61f;)	{
			FPVI_VBUS1.Set(FV, Tmpv, FPVI10_20V, FPVI10_1A, RELAY_ON);
	  	delay_us(100);

			FPVI_VBUS1.MeasureVI(10, 10);
			FPVI_VBUS2.MeasureVI(10, 10);
	  	for(site = 0; site < SITENUM; site++)	{
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

	  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f)) {
					VBS1OV_010_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
					flag[site] = 1;
	  		}
	  	}
	  	if((flag[0] == 1) && (flag[1] == 1))
				break;
	  	Tmpv += ramping_step;
	 	}
	}
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);
  // ======================================================================================== VBS10V: 011
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=98h
  IIC_WRITE(SLVaddr, 0x04, 0x98);

	FPVI_VBUS1.Set(FV, 17.5f, FPVI10_20V, FPVI10_1A, RELAY_ON, 1);
	delay_ms(1);
	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

 	StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FPVI_VBUS1.Set(FV, v4[0], FPVI10_20V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_011_V[site] = v4[0];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v4[1], FPVI10_20V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_011_V[site] = v4[1];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v4[2], FPVI10_20V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_011_V[site] = v4[2];
  			flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for(Tmpv = 16.95f; Tmpv <= 19.01f;)	{
		  FPVI_VBUS1.Set(FV, Tmpv, FPVI10_20V, FPVI10_1A, RELAY_ON);
			delay_us(100);

			FPVI_VBUS1.MeasureVI(10, 10);
			FPVI_VBUS2.MeasureVI(10, 10);
	  	for(site = 0; site < SITENUM; site++)	{
	  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

				if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
					VBS1OV_011_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	  			flag[site] = 1;
	  		}
	  	}
	  	if((flag[0] == 1) && (flag[1] == 1))
				break;
	  	Tmpv += ramping_step;
	  }
	}
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_20V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
  // ======================================================================================== VBS10V: 100
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=A0h
  IIC_WRITE(SLVaddr, 0x04, 0xA0);

	FPVI_VBUS1.Set(FV, 23.5f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_ms(1);
  for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++) 	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FPVI_VBUS1.Set(FV, v5[0], FPVI10_50V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_100_V[site] = v5[0];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v5[1], FPVI10_50V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_100_V[site] = v5[1];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v5[2], FPVI10_50V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_100_V[site] = v5[2];
  			flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for(Tmpv = 22.95f; Tmpv <= 25.01f;)	{
		  FPVI_VBUS1.Set(FV, Tmpv, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	  	delay_us(100);

			FPVI_VBUS1.MeasureVI(10, 10);
			FPVI_VBUS2.MeasureVI(10, 10);
	  	for(site = 0; site < SITENUM; site++)	{
	  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

	  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
					VBS1OV_100_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	  			flag[site] = 1;
	  		}
	  	}
	  	if((flag[0] == 1) && (flag[1] == 1))
				break;
	  	Tmpv += ramping_step;
	  }
	}
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
#endif
  // ======================================================================================== VBS10V: 101
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=A8h
  IIC_WRITE(SLVaddr, 0x04, 0xA8);
	FPVI_VBUS1.Set(FV, 33.0f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_us(500);

  for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

 	StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++){
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FPVI_VBUS1.Set(FV, v6[0], FPVI10_50V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_101_V[site] = v6[0];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v6[1], FPVI10_50V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_101_V[site] = v6[1];
  			flag[site] = 1;
			}
		}

		FPVI_VBUS1.Set(FV, v6[2], FPVI10_50V, FPVI10_1A, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(10, 10);
		FPVI_VBUS2.MeasureVI(10, 10);
		for (site = 0; site < SITENUM; site++)	{
  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
				VBS1OV_101_V[site] = v6[2];
  			flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for(Tmpv = 32.15f; Tmpv <= 35.01f;)	{
			FPVI_VBUS1.Set(FV, Tmpv, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	  	delay_us(100);

			FPVI_VBUS1.MeasureVI(10, 10);
			FPVI_VBUS2.MeasureVI(10, 10);
	  	for(site = 0; site < SITENUM; site++)	{
	  		VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	  		VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

	  		if((flag[site] == 0) && ((VBUS1_V[site] - VBUS2_V[site])*1.0e3f > 100.0f))	{
					VBS1OV_101_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	  			flag[site] = 1;
	  		}
	  	}
	  	if((flag[0] == 1) && (flag[1] == 1))
				break;
	  	Tmpv += ramping_step;
	  }
	}
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_100V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_100V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_100V, FPVI10_100MA, RELAY_ON);
	delay_us(500);
  // ======================================================================================== V120
	cbit128.SetOn(VBUS1_Cap, VBUS2_Cap, MOUT_Cap, VCC_Cap, IMON_1K, EN_MOUT_Short, ADDR_Fovi, INTB_Fovi, VBUS1_Fpvi, SCL_Fovi, SDA_Fovi, FRSEN_Fovi, -1);
	delay_ms(1);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(1);

	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// TM Mode
	FOVI_ADDR.Set(FV, 6.5f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_FRSEN.Set(FV, 6.5f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_ADDR.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_FRSEN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_ADDR.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_OFF);
	FOVI_FRSEN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_OFF);
	delay_us(500);
	FOVI_INTB.Set(FI, 0.0e-12f, FOVI_10V, FOVI_10UA, RELAY_SENSE_ON);
	delay_us(500);
  // TM4
	FOVI_ADDR.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_FRSEN.Set(FV, 1.5f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FOVI_INTB.MeasureVI(20, 5);
  for(site = 0; site < SITENUM; site++)
		V120_V[site] = FOVI_INTB.GetMeasResult(site, MVRET);
	// ========================================================================================
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);
  
	for(site = 0; site < SITENUM; site++)	{
		VBS1OV_000->SetTestResult(site, 0, VBS1OV_000_V[site]);
#ifdef NonShrik
		VBS1OV_001->SetTestResult(site, 0, VBS1OV_001_V[site]);
		VBS1OV_010->SetTestResult(site, 0, VBS1OV_010_V[site]);
		VBS1OV_011->SetTestResult(site, 0, VBS1OV_011_V[site]);
		VBS1OV_100->SetTestResult(site, 0, VBS1OV_100_V[site]);
#endif
		VBS1OV_101->SetTestResult(site, 0, VBS1OV_101_V[site]);
		V120			->SetTestResult(site, 0, V120_V[site]);
	}
  return 0;
}
  // test14 ***************************************** test14 *****************************************
DUT_API int RDSon_Test(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Ron = StsGetParam(funcindex,"Ron");
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double VBUS1_V[SITENUM]	= {0.0f},	VBUS2_V[SITENUM] = {0.0f};
	double VBUS1_C[SITENUM]	= {0.0f},	VBUS2_C[SITENUM] = {0.0f};
	double MOUT_C[SITENUM]	= {0.0f},	MOUT_V[SITENUM]	 = {0.0f};
	double RON_R[SITENUM]		= {0.0f};
	int flag[SITENUM] = {0};
 	BYTE sitesta[SITENUM] = {0};

	cbit128.SetOn(VBUS1_Cap, VBUS2_Cap, MOUT_Cap, VCC_Cap,
								INTB_Fovi, ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, IMON_1K, -1);
	delay_ms(1);
	pwr0V_SET();
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_us(500);
  // ============================================================
	FOVI_INTB.Set(FV, 5.0f, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, -0.05e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	FPVI_VBUS2.Set(FI, -500.0e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);

  FPVI_VBUS1.MeasureVI(20, 5);
  FPVI_VBUS2.MeasureVI(20, 5);
  FPVI_MOUT.MeasureVI(20, 5);

  for(site = 0; site < SITENUM; site++)	{
		VBUS1_V[site]	= FPVI_VBUS1.GetMeasResult(site, MVRET);
  	VBUS1_C[site]	= FPVI_VBUS1.GetMeasResult(site, MIRET);
  	VBUS2_V[site]	= FPVI_VBUS2.GetMeasResult(site, MVRET);
  	VBUS2_C[site]	= FPVI_VBUS2.GetMeasResult(site, MIRET);
  	MOUT_V[site]	= FPVI_MOUT.GetMeasResult(site, MVRET);
  	MOUT_C[site]	= FPVI_MOUT.GetMeasResult(site, MIRET);
		RON_R[site]		= (VBUS1_V[site] - VBUS2_V[site]) / VBUS1_C[site];
	}
	pwr0V_SET();
  // =============================================================
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// =============================================================
	pwrOFF_SET();
	cbit128.SetOn(-1);

  for(site = 0; site < SITENUM; site++)
		Ron->SetTestResult(site, 0, RON_R[site]*1.0e3f);

  return 0;
}
// test15 ***************************************** test15 *****************************************
DUT_API int CurrentMonitor_OutRatio(short funcindex, LPCTSTR funclabel)	{
	//{{AFX_STS_PARAM_PROTOTYPES
    CParam *BS1_IMON1_Ratio_1A = StsGetParam(funcindex,"BS1_IMON1_Ratio_1A");
    CParam *BS1_IMON2_Ratio_1A = StsGetParam(funcindex,"BS1_IMON2_Ratio_1A");
    CParam *BS1_IMON1_Ratio_3A = StsGetParam(funcindex,"BS1_IMON1_Ratio_3A");   // cancel, removed
    CParam *BS1_IMON2_Ratio_3A = StsGetParam(funcindex,"BS1_IMON2_Ratio_3A");   // cancel, removed
    CParam *BS1_IMON1_Ratio_5A = StsGetParam(funcindex,"BS1_IMON1_Ratio_5A");   // cancel, removed
    CParam *BS1_IMON2_Ratio_5A = StsGetParam(funcindex,"BS1_IMON2_Ratio_5A");   // cancel, removed
    CParam *BS2_IMON1_Ratio_1A = StsGetParam(funcindex,"BS2_IMON1_Ratio_1A");
    CParam *BS2_IMON2_Ratio_1A = StsGetParam(funcindex,"BS2_IMON2_Ratio_1A");
    CParam *BS2_IMON1_Ratio_3A = StsGetParam(funcindex,"BS2_IMON1_Ratio_3A");   // cancel, removed
    CParam *BS2_IMON2_Ratio_3A = StsGetParam(funcindex,"BS2_IMON2_Ratio_3A");   // cancel, removed
    CParam *BS2_IMON1_Ratio_5A = StsGetParam(funcindex,"BS2_IMON1_Ratio_5A");   // cancel, removed
    CParam *BS2_IMON2_Ratio_5A = StsGetParam(funcindex,"BS2_IMON2_Ratio_5A");   // cancel, removed
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double IMON1_1A_C[SITENUM] = {0.0f}, IMON1_3A_C[SITENUM]	= {0.0f},	IMON1_5A_C[SITENUM]	= {0.0f};
	double IMON2_1A_C[SITENUM] = {0.0f}, IMON2_3A_C[SITENUM]	= {0.0f},	IMON2_5A_C[SITENUM]	= {0.0f};
	double BS1_IMON1_1A_Ratio_uA[SITENUM]	= {0.0f}, BS1_IMON2_1A_Ratio_uA[SITENUM]	= {0.0f};
	double BS2_IMON1_1A_Ratio_uA[SITENUM]	= {0.0f}, BS2_IMON2_1A_Ratio_uA[SITENUM]	= {0.0f};
	double BS1_IMON1_3A_Ratio_uA[SITENUM]	= {0.0f}, BS1_IMON2_3A_Ratio_uA[SITENUM]	= {0.0f};
	double BS2_IMON1_3A_Ratio_uA[SITENUM]	= {0.0f}, BS2_IMON2_3A_Ratio_uA[SITENUM]	= {0.0f};
	double BS1_IMON1_5A_Ratio_uA[SITENUM]	= {0.0f}, BS1_IMON2_5A_Ratio_uA[SITENUM]	= {0.0f};
	double BS2_IMON1_5A_Ratio_uA[SITENUM]	= {0.0f}, BS2_IMON2_5A_Ratio_uA[SITENUM]	= {0.0f};
	double VBUS1_V[SITENUM]	= {0.0f}, VBUS2_V[SITENUM]	= {0.0f}, INTB_V[SITENUM] = {0.0f};
	double VBUS1_C[SITENUM] = { 0.0f }, VBUS2_C[SITENUM] = { 0.0f };
  int flag[SITENUM] = {0};
  BYTE sitesta[SITENUM] = {0};

	cbit128.SetOn(VBUS1_Cap, MOUT_Cap, VBUS2_Cap, VCC_Cap,
								IMON2_Fovi, INTB_Fovi, ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, IMON1_Fovi, -1);
	delay_ms(1);
	pwr0V_SET();
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
  // ===============================================================================================
	FOVI_INTB.Set(FV, 5.0f, FOVI_10V, FOVI_100UA, RELAY_ON);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);

	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// ====================================================================================== BUS2 1000mA loading
	FPVI_VBUS2.Set(FI, -1000.0e-3f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_ms(1);

	FOVI_IMON1.MeasureVI(200, 10);
  FOVI_IMON2.MeasureVI(200, 10);
  for(site = 0; site < SITENUM; site++)	{
    IMON1_1A_C[site]  = FOVI_IMON1.GetMeasResult(site, MIRET);
    IMON2_1A_C[site]  = FOVI_IMON2.GetMeasResult(site, MIRET);
    IMON1_1A_C[site]  = fabs(IMON1_1A_C[site]);
		IMON2_1A_C[site]  = fabs(IMON2_1A_C[site]);

		if (IMON1_1A_C[site] > 0.0f)
			BS1_IMON1_1A_Ratio_uA[site] = (IMON1_1A_C[site] / 1.0f)*1.0e6f;

		if (IMON2_1A_C[site] > 0.0f)
			BS1_IMON2_1A_Ratio_uA[site] = (IMON2_1A_C[site] / 1.0f)*1.0e6f;
	}
  // ===============================================================================================
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON,2);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_OFF);
	delay_us(500);

	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);

	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=E2h
  IIC_WRITE(SLVaddr, 0x03, 0xE2);
	// ====================================================================================== BUS1 1000mA loading
	FPVI_VBUS1.Set(FI, -1000.0e-3f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_ms(1);

	FOVI_IMON1.MeasureVI(200, 10);
  FOVI_IMON2.MeasureVI(200, 10);
  for(site = 0; site < SITENUM; site++)	{
		IMON1_1A_C[site] = FOVI_IMON1.GetMeasResult(site, MIRET);
    IMON2_1A_C[site] = FOVI_IMON2.GetMeasResult(site, MIRET);
    IMON1_1A_C[site] = fabs(IMON1_1A_C[site]);
		IMON2_1A_C[site] = fabs(IMON2_1A_C[site]);

		if (IMON1_1A_C[site] > 0.0f)
			BS2_IMON1_1A_Ratio_uA[site] = (IMON1_1A_C[site] / 1.0f)*1.0e6f;

		if (IMON2_1A_C[site] > 0.0f)
			BS2_IMON2_1A_Ratio_uA[site] = (IMON2_1A_C[site] / 1.0f)*1.0e6f;
	}
  // ===============================================================================================
	FPVI_VBUS1.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON,2);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_OFF);
	delay_us(500);

	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	// ===============================================================================================
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);

  for(site = 0; site < SITENUM; site++)	{
		BS1_IMON1_Ratio_1A->SetTestResult(site, 0, BS1_IMON1_1A_Ratio_uA[site]);
		BS1_IMON2_Ratio_1A->SetTestResult(site, 0, BS1_IMON2_1A_Ratio_uA[site]);

		BS2_IMON1_Ratio_1A->SetTestResult(site, 0, BS2_IMON1_1A_Ratio_uA[site]);
		BS2_IMON2_Ratio_1A->SetTestResult(site, 0, BS2_IMON2_1A_Ratio_uA[site]);
	}
  return 0;
}
// test16 ***************************************** test16 *****************************************
DUT_API int IMON_ClampV(short funcindex, LPCTSTR funclabel)	{
	//{{AFX_STS_PARAM_PROTOTYPES
  CParam *VIMON1_max = StsGetParam(funcindex,"VIMON1_max");
  CParam *VIMON2_max = StsGetParam(funcindex,"VIMON2_max");
  //}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here

	unsigned char ReceiveData[SITENUM] = {0};
	double BUS1_IL[SITENUM] = {0.0f}, BUS2_IL[SITENUM] = {0.0f};
	double VIMON1_MAX[SITENUM] = {0.0f}, VIMON2_MAX[SITENUM] = {0.0f};
	double vv = 0;
  int flag[SITENUM] = {0};
  BYTE sitesta[SITENUM] = {0};

	cbit128.SetOn(VBUS1_Cap, MOUT_Cap, VBUS2_Cap, VCC_Cap, 
								ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, IMON1_Fovi, IMON2_Fovi, -1);
	delay_ms(1);
	pwr0V_SET();
	// =========================================================================
  // BUS1 = 3.3V
	FPVI_VBUS1.Set(FV, 3.3f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	// EN = 5V
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
  // BUS1 = 5.0V
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON, 5);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
	IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// ========================================================================= Vimon1_max
	// IMON1 = 0V
	FOVI_IMON1.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// IMON2 = 0V
	FOVI_IMON2.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);

	for (site = 0; site < SITENUM; site++)
		flag[site] = 1;

	StsGetSiteStatus(sitesta, SITENUM);
	for (site = 0; site < SITENUM; site++)	{
		if (sitesta[site])
			flag[site] = 0;
	}

	FOVI_IMON2.Set(FV, 3.0f, FOVI_10V, FOVI_100MA, RELAY_ON);
  delay_us(500);
	for (vv = 2.3f; vv <= 3.0f;)	{
		FOVI_IMON2.Set(FV, vv, FOVI_10V, FOVI_1MA, RELAY_ON);
		delay_us(100);

		FOVI_IMON2.MeasureVI(100, 20);
		for (site = 0; site < SITENUM; site++)	{
			BUS1_IL[site] = FOVI_IMON2.GetMeasResult(site, MIRET);

			if ((flag[site] == 0) && ((BUS1_IL[site])*1.0e3f > 0.9e-3f))	{
				FOVI_IMON2.MeasureVI(50, 10);
				VIMON1_MAX[site] = FOVI_IMON2.GetMeasResult(site, MVRET);
				flag[site] = 1;
			}
		}
		if ((flag[0] == 1) && (flag[1] == 1))
			break;
		if (vv < float(2.5))	vv += 50e-3f;
		else vv += 1e-3;
	}

	if(VIMON1_MAX[0] == 0)	{
		////FOVI_IMON2.Set(FV, 3.3f, FOVI_10V, FOVI_100MA, RELAY_ON);		// comment 250606
	  ////delay_us(500);
		for (vv = 2.3f; vv <= 3.0f;)	{
			FOVI_IMON2.Set(FV, vv, FOVI_10V, FOVI_100MA, RELAY_ON, 2);		// 2: 250606
			delay_us(100);

			FOVI_IMON2.MeasureVI(100, 10);
			for (site = 0; site < SITENUM; site++)	{
				BUS1_IL[site] = FOVI_IMON2.GetMeasResult(site, MIRET);

				if ((flag[site] == 0) && ((BUS1_IL[site])*1.0e3f > 1.0e-3f))	{
					////FOVI_IMON2.MeasureVI(50, 10);
					VIMON1_MAX[site] = FOVI_IMON2.GetMeasResult(site, MVRET);
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			if (vv < float(2.5))	vv += 50e-3f;
			else vv += 1e-3;
		}
	}

	// ========================================================================= Vimon2_max
	// EN = 0V
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);

	// EN = 5.0V
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON2.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(100);

	// I2C
	// R=03h, D=C2h
	IIC_WRITE(SLVaddr, 0x03, 0xC2);
	for (site = 0; site < SITENUM; site++)
		flag[site] = 1;

	StsGetSiteStatus(sitesta, SITENUM);
	for (site = 0; site < SITENUM; site++)	{
		if (sitesta[site])
			flag[site] = 0;
	}
	for (vv = 2.3f; vv <= 3.0f;)	{
		FOVI_IMON1.Set(FV, vv, FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(100);

		FOVI_IMON1.MeasureVI(20, 5);
		for (site = 0; site < SITENUM; site++)	{
			BUS2_IL[site] = FOVI_IMON1.GetMeasResult(site, MIRET);

			if ((flag[site] == 0) && ((BUS2_IL[site])*1.0e3f > 1e-3f))	{
				FOVI_IMON2.MeasureVI(50, 10);
				VIMON2_MAX[site] = FOVI_IMON1.GetMeasResult(site, MVRET);
				VIMON2_MAX[site] += float(0.1);	// offset
				flag[site] = 1;
			}
		}
		if ((flag[0] == 1) && (flag[1] == 1))
			break;
		if (vv < float(2.5))	vv += 50e-3f;
		else vv += 1e-3;
	}
	for (site = 0; site < SITENUM; site++)	{
		VIMON1_max->SetTestResult(site, 0, VIMON1_MAX[site]);
		VIMON2_max->SetTestResult(site, 0, VIMON2_MAX[site]);
	}
	return 0;
}
// test17 ***************************************** test17 *****************************************
DUT_API int CurrentLimit_Threshold(short funcindex, LPCTSTR funclabel)	{
	//{{AFX_STS_PARAM_PROTOTYPES
    CParam *BS1_VREFOC_00 = StsGetParam(funcindex,"BS1_VREFOC_00");
    CParam *BS1_VREFOC_01 = StsGetParam(funcindex,"BS1_VREFOC_01");   // removed604
    CParam *BS1_VREFOC_10 = StsGetParam(funcindex,"BS1_VREFOC_10");   // removed604
    CParam *BS1_VREFOC_11 = StsGetParam(funcindex,"BS1_VREFOC_11");   // removed604
    CParam *BS2_VREFOC_00 = StsGetParam(funcindex,"BS2_VREFOC_00");
    CParam *BS2_VREFOC_01 = StsGetParam(funcindex,"BS2_VREFOC_01");   // removed604
    CParam *BS2_VREFOC_10 = StsGetParam(funcindex,"BS2_VREFOC_10");   // removed604
    CParam *BS2_VREFOC_11 = StsGetParam(funcindex,"BS2_VREFOC_11");   // removed604
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM]={0};
	double VBUS1_V[SITENUM]	= {0.0f}, VBUS2_V[SITENUM]	= {0.0f}, INTB_V[SITENUM]	= {0.0f};
	double VBUS1_C[SITENUM] = { 0.0f }, VBUS2_C[SITENUM] = { 0.0f };
	double BS1_VREFOC_00_V[SITENUM]	= {0.0f}, BS1_VREFOC_01_V[SITENUM]	= {0.0f}, BS1_VREFOC_10_V[SITENUM] = {0.0f}, BS1_VREFOC_11_V[SITENUM]	= {0.0f};
	double BS2_VREFOC_00_V[SITENUM]	= {0.0f}, BS2_VREFOC_01_V[SITENUM]	= {0.0f}, BS2_VREFOC_10_V[SITENUM] = {0.0f}, BS2_VREFOC_11_V[SITENUM]	= {0.0f};
	double voc00[3] = { 0.39f, 0.52f, 0.6f }, voc01[3] = { 0.59f, 0.72f, 0.8f }, voc10[3] = { 1.19f, 1.35f, 1.44f }, voc11[3] = { 1.99f, 2.25f, 2.4f };
	double ramping_step = 1e-3f;
  int flag[SITENUM] = {0};
	short GONOGO = BS1_VREFOC_00->GetConditionCurSelDouble("goPassFail");	// 0:Ramp	1:P/F
  BYTE sitesta[SITENUM] = {0};

	cbit128.SetOn(VBUS1_Cap, MOUT_Cap, VBUS2_Cap, VCC_Cap,
								IMON1_Fovi, IMON2_Fovi, INTB_Fovi, ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, -1);
	delay_ms(1);
	pwr0V_SET();
  // =================================================================================================== BUS1: 00
	FOVI_INTB.Set(FV, 5.0f, FOVI_10V, FOVI_100UA, RELAY_ON);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FPVI_VBUS2.Set(FI, -0.0e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03 ,0xC2);
	// R=04h, D=00h
  IIC_WRITE(SLVaddr, 0x04, 0x00);
	// R=05h, D=40h
	IIC_WRITE(SLVaddr, 0x05, 0x40);

	FOVI_IMON1.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.4f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, -1.0e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);

	FPVI_VBUS2.MeasureVI(50, 20);
  for(site = 0; site < SITENUM; site++)
    VBUS2_V[site]  = FPVI_VBUS2.GetMeasResult(site, MVRET);

 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FOVI_IMON2.Set(FV, voc00[0], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_00_V[site] = voc00[0];
				flag[site] = 1;
			}
		}

		FOVI_IMON2.Set(FV, voc00[1], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_00_V[site] = voc00[1];
				flag[site] = 1;
			}
		}

		FOVI_IMON2.Set(FV, voc00[2], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_00_V[site] = voc00[2];
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for (Tmpv = 0.39f; Tmpv <= 0.6f;)	{
			FOVI_IMON2.Set(FV, Tmpv, FOVI_10V, FOVI_10MA, RELAY_ON);
			delay_us(100);

			FPVI_VBUS2.MeasureVI(50, 10);
			FOVI_IMON2.MeasureVI(50, 10);
			for (site = 0; site < SITENUM; site++)	{
				VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

				if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
					BS1_VREFOC_00_V[site] = FOVI_IMON2.GetMeasResult(site, MVRET);
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	}
#ifdef NonShrink
	// =================================================================================================== BUS1: 01
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FOVI_IMON1.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.6f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=40h
  IIC_WRITE(SLVaddr, 0x04, 0x40);
	// R=05h, D=40h
	IIC_WRITE(SLVaddr, 0x05, 0x40);

	FPVI_VBUS2.MeasureVI(50, 20);
  for(site = 0; site < SITENUM; site++)
    VBUS2_V[site]  = FPVI_VBUS2.GetMeasResult(site, MVRET);

 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

 	StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FOVI_IMON2.Set(FV, voc01[0], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_01_V[site] = voc01[0];
				flag[site] = 1;
			}
		}

		FOVI_IMON2.Set(FV, voc01[1], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_01_V[site] = voc01[1];
				flag[site] = 1;
			}
		}

		FOVI_IMON2.Set(FV, voc11[2], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_01_V[site] = voc01[2];
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for (Tmpv = 0.59f; Tmpv <= 0.9f;)	{
			FOVI_IMON2.Set(FV, Tmpv, FOVI_10V, FOVI_10MA, RELAY_ON);
			delay_us(100);

			FPVI_VBUS2.MeasureVI(50, 10);
			FOVI_IMON2.MeasureVI(50, 10);
			for (site = 0; site < SITENUM; site++)	{
				VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

				if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
					BS1_VREFOC_01_V[site] = FOVI_IMON2.GetMeasResult(site, MVRET);
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	}
	// =================================================================================================== BUS1: 10
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FOVI_IMON1.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 1.2f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=80h
	IIC_WRITE(SLVaddr, 0x04, 0x80);
	// R=05h, D=40h
  IIC_WRITE(SLVaddr, 0x05, 0x40);

	FPVI_VBUS2.MeasureVI(50, 20);
  for(site = 0; site < SITENUM; site++)
    VBUS2_V[site]  = FPVI_VBUS2.GetMeasResult(site, MVRET);

 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
  for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FOVI_IMON2.Set(FV, voc10[0], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_10_V[site] = voc10[0];
				flag[site] = 1;
			}
		}

		FOVI_IMON2.Set(FV, voc10[1], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_10_V[site] = voc10[1];
				flag[site] = 1;
			}
		}

		FOVI_IMON2.Set(FV, voc10[2], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_10_V[site] = voc10[2];
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for (Tmpv = 1.2f; Tmpv <= 1.6f;)	{
			FOVI_IMON2.Set(FV, Tmpv, FOVI_10V, FOVI_10MA, RELAY_ON);
			delay_us(100);

			FPVI_VBUS2.MeasureVI(50, 10);
			FOVI_IMON2.MeasureVI(50, 10);
			for (site = 0; site < SITENUM; site++)	{
				VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

				if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
					BS1_VREFOC_10_V[site] = FOVI_IMON2.GetMeasResult(site, MVRET);
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	}
	// =================================================================================================== BUS1: 11
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FOVI_IMON1.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 1.3f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=C0h
	IIC_WRITE(SLVaddr, 0x04, 0xC0);
	// R=05h, D=40h
  IIC_WRITE(SLVaddr, 0x05, 0x40);

	FOVI_IMON2.Set(FV, 1.4f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FOVI_IMON2.Set(FV, 1.5f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON2.Set(FV, 1.6f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON2.Set(FV, 1.8f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON2.Set(FV, 1.95f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
  for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }

	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FOVI_IMON2.Set(FV, voc11[0], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_11_V[site] = voc11[0];
				flag[site] = 1;
			}
		}

		FOVI_IMON2.Set(FV, voc11[1], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_11_V[site] = voc11[1];
				flag[site] = 1;
			}
		}

		FOVI_IMON2.Set(FV, voc11[2], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS2.MeasureVI(50, 10);
		FOVI_IMON2.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
				BS1_VREFOC_11_V[site] = voc11[2];
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for (Tmpv = 1.95f; Tmpv <= 2.5f;)	{
			FOVI_IMON2.Set(FV, Tmpv, FOVI_10V, FOVI_10MA, RELAY_ON);
			delay_us(100);

			FPVI_VBUS2.MeasureVI(50, 10);
			FOVI_IMON2.MeasureVI(50, 10);
			for (site = 0; site < SITENUM; site++)	{
				VBUS2_V[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

				if ((flag[site] == 0) && (VBUS2_V[site] < 4.0f))	{
					BS1_VREFOC_11_V[site] = FOVI_IMON2.GetMeasResult(site, MVRET);
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	}
#endif
	// =================================================================================================== BUS2: 00
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_IMON1.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_us(500);
	FPVI_VBUS1.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=E0h
	IIC_WRITE(SLVaddr, 0x03, 0xE0);
  // R=04h, D=00h
	IIC_WRITE(SLVaddr, 0x04, 0x00);
	// R=05h, D=40h
  IIC_WRITE(SLVaddr, 0x05, 0x40);

	FOVI_IMON1.Set(FV, 0.4f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FI, -1.0e-3f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.MeasureVI(50, 20);
  for(site = 0; site < SITENUM; site++)
    VBUS1_V[site]  = FPVI_VBUS1.GetMeasResult(site, MVRET);

 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

 	StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
		if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FOVI_IMON1.Set(FV, voc00[0], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_00_V[site] = voc00[0];
				flag[site] = 1;
			}
		}

		FOVI_IMON1.Set(FV, voc00[1], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_00_V[site] = voc00[1];
				flag[site] = 1;
			}
		}

		FOVI_IMON1.Set(FV, voc00[2], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_00_V[site] = voc00[2];
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for (Tmpv = 0.39f; Tmpv <= 0.6f;)	{
			FOVI_IMON1.Set(FV, Tmpv, FOVI_10V, FOVI_10MA, RELAY_ON);
			delay_us(100);

			FPVI_VBUS1.MeasureVI(50, 10);
			FOVI_IMON1.MeasureVI(50, 10);
			for (site = 0; site < SITENUM; site++)	{
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

				if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
					BS2_VREFOC_00_V[site] = FOVI_IMON1.GetMeasResult(site, MVRET);
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	}
#ifdef NonShrink
	// =================================================================================================== BUS2: 01
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FOVI_IMON1.Set(FV, 0.6f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=E0h
  IIC_WRITE(SLVaddr, 0x03, 0xE0);
	// R=04h, D=40h
	IIC_WRITE(SLVaddr, 0x04, 0x40);
	// R=05h, D=40h
  IIC_WRITE(SLVaddr, 0x05, 0x40);

	FPVI_VBUS1.MeasureVI(50, 20);
  for(site = 0; site < SITENUM; site++)
    VBUS1_V[site]  = FPVI_VBUS1.GetMeasResult(site, MVRET);

 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FOVI_IMON1.Set(FV, voc01[0], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_01_V[site] = voc01[0];
				flag[site] = 1;
			}
		}

		FOVI_IMON1.Set(FV, voc01[1], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_01_V[site] = voc01[1];
				flag[site] = 1;
			}
		}

		FOVI_IMON1.Set(FV, voc01[2], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_01_V[site] = voc01[2];
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for (Tmpv = 0.39f; Tmpv <= 0.9f;)	{
			FOVI_IMON1.Set(FV, Tmpv, FOVI_10V, FOVI_10MA, RELAY_ON);
			delay_us(100);

			FPVI_VBUS1.MeasureVI(50, 10);
			FOVI_IMON1.MeasureVI(50, 10);
			for (site = 0; site < SITENUM; site++)	{
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

				if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
					BS2_VREFOC_01_V[site] = FOVI_IMON1.GetMeasResult(site, MVRET);
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	}
	// =================================================================================================== BUS2: 10
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FOVI_IMON1.Set(FV, 1.2f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=E0h
	IIC_WRITE(SLVaddr, 0x03, 0xE0);
  // R=04h, D=80h
  IIC_WRITE(SLVaddr, 0x04, 0x80);
  // R=05h, D=40h
  IIC_WRITE(SLVaddr, 0x05, 0x40);

	FPVI_VBUS1.MeasureVI(50, 20);
  for(site = 0; site < SITENUM; site++)
    VBUS1_V[site]  = FPVI_VBUS1.GetMeasResult(site, MVRET);

 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

 	StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FOVI_IMON1.Set(FV, voc10[0], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_10_V[site] = voc10[0];
				flag[site] = 1;
			}
		}

		FOVI_IMON1.Set(FV, voc10[1], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_10_V[site] = voc10[1];
				flag[site] = 1;
			}
		}

		FOVI_IMON1.Set(FV, voc10[2], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_10_V[site] = voc10[2];
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for (Tmpv = 1.2f; Tmpv <= 1.6f;)	{
			FOVI_IMON1.Set(FV, Tmpv, FOVI_10V, FOVI_10MA, RELAY_ON);
			delay_us(100);

			FPVI_VBUS1.MeasureVI(50, 10);
			FOVI_IMON1.MeasureVI(50, 10);
			for (site = 0; site < SITENUM; site++)	{
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

				if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
					BS2_VREFOC_10_V[site] = FOVI_IMON1.GetMeasResult(site, MVRET);
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	}
	// =================================================================================================== BUS2: 11
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	FOVI_IMON1.Set(FV, 1.3f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=E0h
	IIC_WRITE(SLVaddr, 0x03, 0xE0);
	// R=04h, D=C0h
  IIC_WRITE(SLVaddr, 0x04, 0xC0);
  // R=05h, D=40h
  IIC_WRITE(SLVaddr, 0x05, 0x40);

	FOVI_IMON1.Set(FV, 1.4f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON1.Set(FV, 1.5f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON1.Set(FV, 1.6f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON1.Set(FV, 1.7f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON1.Set(FV, 1.8f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON1.Set(FV, 1.95f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.MeasureVI(50, 20);
 	for(site = 0; site < SITENUM; site++)
    VBUS1_V[site]  = FPVI_VBUS1.GetMeasResult(site, MVRET);

 	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

 	StsGetSiteStatus(sitesta, SITENUM);
 	for(site = 0; site < SITENUM; site++)	{
		if(sitesta[site])
 			flag[site] = 0;
  }
	// ******************************************* GONOGO *******************************************
	if (GONOGO)	{
		FOVI_IMON1.Set(FV, voc11[0], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_11_V[site] = voc11[0];
				flag[site] = 1;
			}
		}

		FOVI_IMON1.Set(FV, voc11[1], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_11_V[site] = voc11[1];
				flag[site] = 1;
			}
		}

		FOVI_IMON1.Set(FV, voc11[2], FOVI_10V, FOVI_10MA, RELAY_ON);
		delay_us(500);
		FPVI_VBUS1.MeasureVI(50, 10);
		FOVI_IMON1.MeasureVI(50, 10);
		for (site = 0; site < SITENUM; site++)	{
			VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
			if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
				BS2_VREFOC_11_V[site] = voc11[2];
				flag[site] = 1;
			}
		}
	}
	// ******************************************* RAMPING *******************************************
	else	{
		for (Tmpv = 1.95f; Tmpv <= 2.5f;)	{
			FOVI_IMON1.Set(FV, Tmpv, FOVI_10V, FOVI_10MA, RELAY_ON);
			delay_us(100);

			FPVI_VBUS1.MeasureVI(50, 10);
			FOVI_IMON1.MeasureVI(50, 10);
			for (site = 0; site < SITENUM; site++)	{
				VBUS1_V[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

				if ((flag[site] == 0) && (VBUS1_V[site] < 4.0f))	{
					BS2_VREFOC_11_V[site] = FOVI_IMON1.GetMeasResult(site, MVRET);
					flag[site] = 1;
				}
			}
			if ((flag[0] == 1) && (flag[1] == 1))
				break;
			Tmpv += ramping_step;
		}
	}
#endif
  // ===================================================================================================
	FPVI_VBUS1.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// ===================================================================================================
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);

  for(site = 0; site < SITENUM; site++)	{
		BS1_VREFOC_00->SetTestResult(site, 0, BS1_VREFOC_00_V[site]);
		BS2_VREFOC_00->SetTestResult(site, 0, BS2_VREFOC_00_V[site]);
#ifdef NonShrink
		BS1_VREFOC_01->SetTestResult(site, 0, BS1_VREFOC_01_V[site]);
		BS1_VREFOC_10->SetTestResult(site, 0, BS1_VREFOC_10_V[site]);
		BS1_VREFOC_11->SetTestResult(site, 0, BS1_VREFOC_11_V[site]);
		BS2_VREFOC_01->SetTestResult(site, 0, BS2_VREFOC_01_V[site]);
		BS2_VREFOC_10->SetTestResult(site, 0, BS2_VREFOC_10_V[site]);
		BS2_VREFOC_11->SetTestResult(site, 0, BS2_VREFOC_11_V[site]);
#endif
	}
  return 0;
}
// test18 ***************************************** test18 *****************************************
DUT_API int CL_ResponseTime(short funcindex, LPCTSTR funclabel)	{
	//{{AFX_STS_PARAM_PROTOTYPES
  CParam *tOC_00 = StsGetParam(funcindex,"tOC_00");
  CParam *tOC_01 = StsGetParam(funcindex,"tOC_01");
  CParam *tOC_10 = StsGetParam(funcindex,"tOC_10");   // removed604
  CParam *tOC_11 = StsGetParam(funcindex,"tOC_11");   // removed604
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double tOC_00_T[SITENUM]	= { 0.0f }, tOC_01_T[SITENUM]	= { 0.0f }, tOC_10_T[SITENUM]	= { 0.0f }, tOC_11_T[SITENUM] = { 0.0f };
	double VBUS1_V[SITENUM]		= { 0.0f }, VBUS2_V[SITENUM]	= { 0.0f }, INTB_V[SITENUM]		= { 0.0f };
	double VBUS1_C[SITENUM]		= { 0.0f }, VBUS2_C[SITENUM]	= { 0.0f };
	double VBUS2_RES_V[SITENUM][2000] = {{ 0.0f },{ 0.0f }};
	int L1=0, GetT1_T2[SITENUM]	= { 0 };
  int flag[SITENUM] = { 0 };
  BYTE sitesta[SITENUM] = { 0 };

	cbit128.SetOn(VBUS1_Cap, MOUT_Cap, VBUS2_Cap, VCC_Cap,
								IMON1_Fovi, IMON2_Fovi, INTB_Fovi, ADDR_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, -1);
	delay_ms(1);
	pwr0V_SET();
	// ================================================================================== tOC: 00
	FOVI_INTB.Set(FV, 5.0f, FOVI_10V, FOVI_100UA, RELAY_ON);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// VBUS1=5V
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);//, 5);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// IMON1, IMON2 GND
	FOVI_IMON1.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.04f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
  // I2C
	// R=03h, D=C2h
	IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=00h
  IIC_WRITE(SLVaddr, 0x04, 0x00);
	// R=05h, D=00h
  IIC_WRITE(SLVaddr, 0x05, 0x00);

	FPVI_VBUS2.Set(FI, -1.0e-6f, FPVI10_10V, FPVI10_1A, RELAY_SENSE_ON);
	delay_ms(1);
	FOVI_IMON2.Set(FV, 0.6f, FOVI_10V, FOVI_10MA, RELAY_ON);

	FPVI_VBUS2.MeasureVI(500, 5);
  for(site = 0; site < SITENUM; site++)
    FPVI_VBUS2.BlockRead(site, 0, 500, VBUS2_RES_V[site], MVRET);

	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
  for(site = 0; site < SITENUM; site++)	{
		if (VBUS2_RES_V[site][0] > 4.9f)	{
      for(L1 = 0; L1 < 500; L1+=1)	{
				if (VBUS2_RES_V[site][L1] <= 4.9f)	{
					GetT1_T2[site] = L1 *5.0f;
						tOC_00_T[site] = GetT1_T2[site] * 1.0e-3f;
						break;
				 }
			 }
		}
		else	{
			GetT1_T2[site] = 0;
			tOC_00_T[site] = 0.0f;
			break;
		}
	}
  // ================================================================================== tOC: 01
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON1.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.4f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=00h
  IIC_WRITE(SLVaddr, 0x04, 0x00);
	// R=05h, D=40h
  IIC_WRITE(SLVaddr, 0x05, 0x40);

	FOVI_IMON2.Set(FV, 0.6f, FOVI_10V, FOVI_10MA, RELAY_ON);

	FPVI_VBUS2.MeasureVI(300, 5);
  for(site = 0; site < SITENUM; site++)
    FPVI_VBUS2.BlockRead(site, 0, 300, VBUS2_RES_V[site], MVRET);

	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
  for(site = 0; site < SITENUM; site++)	{
		if (VBUS2_RES_V[site][0] > 4.9f)	{
      for(L1=0; L1 < 300; L1 += 1)	{
        if (VBUS2_RES_V[site][L1] <= 4.9f)	{
					GetT1_T2[site] = L1 * 5.0f;
					tOC_01_T[site] = GetT1_T2[site] * 1.0e-3f;
					break;
				}
			}
		}
		else	{
			GetT1_T2[site] = 0;
			tOC_01_T[site] = 0.0f;
			break;
		}
	}
#ifdef NonShrink
	// ================================================================================== tOC: 10
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON1.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.4f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=00h
  IIC_WRITE(SLVaddr, 0x04, 0x00);
	// R=05h, D=80h
	IIC_WRITE(SLVaddr, 0x05, 0x80);

	FOVI_IMON2.Set(FV, 0.6f, FOVI_10V, FOVI_10MA, RELAY_ON);

	FPVI_VBUS2.MeasureVI(100, 100);
  for(site = 0; site < SITENUM; site++)
    FPVI_VBUS2.BlockRead(site, 0, 100, VBUS2_RES_V[site], MVRET);

	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
  for(site = 0; site < SITENUM; site++)	{
		if (VBUS2_RES_V[site][0] > 4.9f)	{
			for(L1=0; L1 < 100; L1 +=1)	{
        if (VBUS2_RES_V[site][L1] <= 4.9f)	{
					GetT1_T2[site] = L1 * 100.0f;
					tOC_10_T[site] = GetT1_T2[site] * 1.0e-3f;
					break;
				}
			}
		}
		else	{
			GetT1_T2[site] = 0;
			tOC_10_T[site] = 0.0f;
			break;
		}
	}
	// ================================================================================== tOC: 11
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 2.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_IMON1.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.4f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// R=04h, D=00h
  IIC_WRITE(SLVaddr, 0x04, 0x00);
	// R=05h, D=C0h
  IIC_WRITE(SLVaddr, 0x05, 0xC0);
	FOVI_IMON2.Set(FV, 0.6f, FOVI_10V, FOVI_10MA, RELAY_ON);

	FPVI_VBUS2.MeasureVI(100, 100);
	for(site = 0; site < SITENUM; site++)
		FPVI_VBUS2.BlockRead(site, 0, 100, VBUS2_RES_V[site], MVRET);

	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
  for(site = 0; site < SITENUM; site++)	{
		if (VBUS2_RES_V[site][0] > 4.9f)	{
			for(L1=0; L1 < 100; L1 +=1)	{
				if (VBUS2_RES_V[site][L1] <= 4.9f)	{
					GetT1_T2[site] = L1 * 100.0f;
					tOC_11_T[site] = GetT1_T2[site] * 1.0e-3f;
					break;
				}
			}
		}
		else	{
			GetT1_T2[site] = 0;
			tOC_11_T[site] = 0.0f;
			break;
		}
	}
#endif
  // ==================================================================================
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// ==================================================================================
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);
  
	for(site = 0; site < SITENUM; site++)	{
		tOC_00->SetTestResult(site, 0, tOC_00_T[site]);
		tOC_01->SetTestResult(site, 0, tOC_01_T[site]*1e3);
#ifdef NonShrink
		tOC_10->SetTestResult(site, 0, tOC_10_T[site]);
		tOC_11->SetTestResult(site, 0, tOC_11_T[site]);
#endif
	}
  return 0;
}
// test19 ***************************************** test19 *****************************************
DUT_API int IMax_Threshold(short funcindex, LPCTSTR funclabel)	{
	//{{AFX_STS_PARAM_PROTOTYPES
    CParam *IMAX12TM = StsGetParam(funcindex,"IMAX12TM");
    CParam *IMAX12_X = StsGetParam(funcindex,"IMAX12_X");
    CParam *IMAX21TM = StsGetParam(funcindex,"IMAX21TM");
    CParam *IMAX21_X = StsGetParam(funcindex,"IMAX21_X");
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = { 0 };
	double VBUS_NL[SITENUM] = { 0.0f }, IMAX12_C[SITENUM] = { 0.0f }, IMAX21_C[SITENUM] = { 0.0f }, ii[SITENUM] = { 0.0f };
	int flag[SITENUM] = { 0 };
	float iLoad = 0;
	BYTE sitesta[SITENUM] = { 0 };

	cbit128.SetOn(VBUS1_Cap, MOUT_Cap, VBUS2_Cap, VCC_Cap,
								IMON1_Fovi, IMON2_Fovi, ADDR_Fovi, FRSEN_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_MOUT_Short,
								INTB_100K_Fovi, -1);
	delay_ms(1);
	// =================================================================================================== IMAX12: 0, VBUS1 --> VBUS2
	FOVI_IMON1.Set(FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	// VBUS1=VBUS2=5V, enable the XA95
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	// VEN
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);

	FOVI_INTB_100K.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	setupTM(5.0f, 5.3f, 5.0f);
	// VBUS2 loading
	FPVI_VBUS2.Set(FI, -0.05e-6f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=C2h
	IIC_WRITE(SLVaddrC, 0x03, 0xC2);	// BUS1 -> BUS2
	delay_us(500);
	FOVI_ADDR.Set(FV, float(0), FOVI_10V, FOVI_1A, RELAY_OFF);
	FOVI_ADDR.Set(FV, float(0), FOVI_10V, FOVI_1A, RELAY_OFF);
	delay_us(500);

	// TM3
	TM_SEL(0.0f, 5.0f);
	for (site = 0; site < SITENUM; site++)
		flag[site] = 1;

	StsGetSiteStatus(sitesta, SITENUM);
	for (site = 0; site < SITENUM; site++)	{
		if (sitesta[site])
			flag[site] = 0;
	}

	//FPVI_VBUS2.MeasureVI(50, 5);
	//for (site = 0; site < SITENUM; site++)
	//	VBUS_NL[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);

	//FPVI_VBUS2.Set(FI, -10.01e-3f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	//delay_us(500);

	//FPVI_VBUS2.MeasureVI(50, 5);
	//for (site = 0; site < SITENUM; site++)	{
	//	VBUS_NL[site] = FPVI_VBUS2.GetMeasResult(site, MVRET);
	//}
	//delay_us(500);

	for (iLoad = 1600; iLoad < 3000;)	{
		FPVI_VBUS2.Set(FI, -iLoad*1e-3f, FPVI10_10V, FPVI10_10A, RELAY_ON, 1);
		FPVI_VBUS2.MeasureVI(10, 5);

		for (int ii = 0; ii < SITENUM; ii++)	{
			adresult2[ii] = FPVI_VBUS2.GetMeasResult(ii, MVRET);
			if (adresult2[ii] < float(1) && flag[ii] == 0)	{
				FPVI_VBUS2.Set(FI, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);

				IMAX12_C[ii] = iLoad;
				flag[ii] = 1;
			}
		}
		if (flag[0] && flag[1])
			break;
		iLoad += float(25);
	}
	// =================================================================================================== IMAX21: 1, VBUS2 --> VBUS1
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);
	delay_ms(1);

	cbit128.SetOn(VBUS1_Cap, MOUT_Cap, VBUS2_Cap, VCC_Cap,
								IMON1_Fovi, IMON2_Fovi, ADDR_Fovi, FRSEN_Fovi, VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_MOUT_Short,
								INTB_100K_Fovi, -1);
	delay_ms(1);
	FOVI_IMON1.Set(FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	FOVI_IMON2.Set(FV, 0.0f, FOVI_2V, FOVI_10MA, RELAY_ON);
	// VBUS1=VBUS2=5V, enable the XA95
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	FPVI_VBUS2.Set(FV, 5.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	// VEN
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);

	FOVI_INTB_100K.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	setupTM(5.0f, 5.3f, 5.0f);
	// VBUS2 loading
	FPVI_VBUS1.Set(FI, -0.05e-6f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=C2h
	IIC_WRITE(SLVaddrC, 0x03, 0xE2);	// BUS2 -> BUS1
	delay_ms(1);
	FOVI_ADDR.Set(FV, float(0), FOVI_10V, FOVI_1A, RELAY_OFF);
	FOVI_ADDR.Set(FV, float(0), FOVI_10V, FOVI_1A, RELAY_OFF);
	delay_ms(1);

	// TM3
	TM_SEL(0.0f, 5.0f);
	for (site = 0; site < SITENUM; site++)
		flag[site] = 1;

	StsGetSiteStatus(sitesta, SITENUM);
	for (site = 0; site < SITENUM; site++)	{
		if (sitesta[site])
			flag[site] = 0;
	}

	//FPVI_VBUS1.MeasureVI(10, 5);
	//for (site = 0; site < SITENUM; site++)
	//	VBUS_NL[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);

	//FPVI_VBUS1.Set(FI, -10.01e-3f, FPVI10_10V, FPVI10_10A, RELAY_ON);
	//delay_ms(1);

	//FPVI_VBUS1.MeasureVI(10, 5);
	//for (site = 0; site < SITENUM; site++)	{
	//	VBUS_NL[site] = FPVI_VBUS1.GetMeasResult(site, MVRET);
	//}
	//delay_ms(1);

	for (iLoad = 1600; iLoad < 3000;)	{
		FPVI_VBUS1.Set(FI, -iLoad*1e-3f, FPVI10_10V, FPVI10_10A, RELAY_ON, 1);
		FPVI_VBUS1.MeasureVI(10, 5);

		for (int ii = 0; ii < SITENUM; ii++)	{
			adresult2[ii] = FPVI_VBUS1.GetMeasResult(ii, MVRET);
			if (adresult2[ii] < float(1) && flag[ii] == 0)	{
				FPVI_VBUS1.Set(FI, 0.0f, FPVI10_10V, FPVI10_10A, RELAY_ON);

				IMAX21_C[ii] = iLoad;
				flag[ii] = 1;
			}
		}
		if (flag[0] && flag[1])
			break;
		iLoad += float(25);
	}
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);
	delay_us(100);
	
	for (site = 0; site < SITENUM; site++)	{
		IMAX12TM->SetTestResult(site, 0, IMAX12_C[site]);
		IMAX12_X->SetTestResult(site, 0, IMAX12_C[site]*4.55);
		IMAX21TM->SetTestResult(site, 0, IMAX21_C[site]);
		IMAX21_X->SetTestResult(site, 0, IMAX21_C[site]*4.61);
	}
  return 0;
}
// test20 ***************************************** test20 *****************************************
DUT_API int ADDR_PD_Current(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *I_ADDR = StsGetParam(funcindex,"I_ADDR");
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	double ADDR_C[SITENUM] = {0.0f};
  int flag[SITENUM] = {0};
  BYTE sitesta[SITENUM] = {0};

	cbit128.SetOn(VCC_Cap,
								VBUS1_Fpvi, EN_Fovi, ADDR_Fovi, IMON_1K, EN_MOUT_Short, -1);
	delay_ms(1);
	pwr0V_SET();
  // ======================================================================================
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_ADDR.Set(FV, 3.3f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_ADDR.Set(FV, 3.3f, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_us(500);
	FOVI_ADDR.Set(FV, 3.3f, FOVI_10V, FOVI_10UA, RELAY_ON);
	delay_us(500);

  FOVI_ADDR.MeasureVI(10, 10);
	for (site = 0; site < SITENUM; site++)	{
		adresult[site] = FOVI_ADDR.GetMeasResult(site, MVRET);
		if (adresult[site] > float(3.29))
			ADDR_C[site] = FOVI_ADDR.GetMeasResult(site, MIRET) * 1.0e6f;
	}
	// ======================================================================================
	pwr0V_SET();
	pwrOFF_SET();

	cbit128.SetOn(-1);
  for(site = 0; site < SITENUM; site++)
		I_ADDR->SetTestResult(site, 0, ADDR_C[site]);

  return 0;
}
// test21 ***************************************** test21 *****************************************
DUT_API int INTB_OutputLowV(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *RINTB = StsGetParam(funcindex,"RINTB");
    CParam *VFOL = StsGetParam(funcindex,"VFOL");
    CParam *ILKG_INTB = StsGetParam(funcindex,"ILKG_INTB");
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double INTB_C[SITENUM]		= {0.0f}, INTB_V[SITENUM]			= {0.0f};
	double INTB100K_C[SITENUM]= {0.0f}, INTB100K_V[SITENUM]	= {0.0f};
  double RINTB_R[SITENUM]		= {0.0f}, VFOL_V[SITENUM]			= {0.0f};
  int flag[SITENUM] = {0};
  BYTE sitesta[SITENUM] = {0};

	cbit128.SetOn(VCC_Cap,
								ADDR_Fovi, VBUS1_Fpvi, INTB_Fovi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, FRSEN_Fovi, INTB_100K_Fovi, IMON_1K, -1);
	delay_ms(1);
	pwr0V_SET();

	FOVI_INTB.Set			(FI, 0.0e-12f, FOVI_10V, FOVI_10UA, RELAY_SENSE_ON);
	FPVI_VBUS2.Set		(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_us(500);
  // ==================================================================================== RINTB & VINTB
  FOVI_INTB_100K.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// VBUS1=5.5V
	FPVI_VBUS1.Set(FV, 5.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);
	// VBUS1=6.5V
	FPVI_VBUS1.Set(FV, 6.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);

  FOVI_INTB.MeasureVI(10, 10);
  FOVI_INTB_100K.MeasureVI(10, 10);
  for(site = 0; site < SITENUM; site++)	{
		INTB_V[site] = FOVI_INTB.GetMeasResult(site, MVRET);
  	INTB100K_C[site] = FOVI_INTB_100K.GetMeasResult(site, MIRET);
    RINTB_R[site] = INTB_V[site]/INTB100K_C[site];
		VFOL_V[site] = RINTB_R[site] * 1.0e-3f;
	}
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON, 5);
	delay_us(500);
	// ==================================================================================== INTB LEAK
	cbit128.SetOn(VCC_Cap,
								ADDR_Fovi, VBUS1_Fpvi, INTB_Fovi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, IMON_1K, -1);
	delay_ms(1);

	FOVI_INTB.Set(FV, 0.0f, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_us(500);
	// VBUS1=5.5V
	FPVI_VBUS1.Set(FV, 5.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// EN FLOATING
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_OFF);
	delay_us(500);
	// INTB=5.5V
	FOVI_INTB.Set(FV, 5.5f, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_us(500);
	FOVI_INTB.Set(FV, 5.5f, FOVI_10V, FOVI_10UA, RELAY_ON);
	delay_ms(2);

  FOVI_INTB.MeasureVI(300, 10);
  for(site = 0; site < SITENUM; site++)
  	INTB_C[site] = fabs(FOVI_INTB.GetMeasResult(site, MIRET));

	FOVI_INTB.Set(FV, 0.0f, FOVI_10V, FOVI_10UA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS2.Set(FI, 0.0e-12f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// ====================================================================================
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);

  for(site = 0; site < SITENUM; site++)	{
		RINTB->SetTestResult(site, 0, RINTB_R[site]);
		VFOL->SetTestResult(site, 0, VFOL_V[site]*1e3);
		ILKG_INTB->SetTestResult(site, 0, INTB_C[site]*1.0e9f);
	}
  return 0;
}
// test22 ***************************************** test22 *****************************************
DUT_API int INTB_DelayTime(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *TINTBDLY1_00 = StsGetParam(funcindex,"TINTBDLY1_00");
    CParam *TINTBDLY1_01 = StsGetParam(funcindex,"TINTBDLY1_01");
    CParam *TINTBDLY1_10 = StsGetParam(funcindex,"TINTBDLY1_10");   // removed604
    CParam *TINTBDLY1_11 = StsGetParam(funcindex,"TINTBDLY1_11");   // removed604
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	unsigned char ReceiveData[SITENUM] = {0};
	double tINTB_00[SITENUM] = {0.0f}, tINTB_01[SITENUM] = {0.0f}, tINTB_10[SITENUM] = {0.0f}, tINTB_11[SITENUM] = {0.0f};
  int flag[SITENUM] = {0};
  BYTE sitesta[SITENUM] = {0};

	for(site = 0; site < SITENUM; site++)
		flag[site] = 1;

  StsGetSiteStatus(sitesta, SITENUM);
  for(site = 0; site < SITENUM; site++)	{
  	if(sitesta[site])
 			flag[site] = 0;
  }
	cbit128.SetOn(VBUS1_Cap, MOUT_Cap, VBUS2_Cap, VCC_Cap,
								VBUS1_Fpvi, VBUS2_Fpvi, EXT_SCL_SDA, SCL_Fovi, SDA_Fovi, EN_Fovi, ADDR_Fovi,
								IMON_1K, VBUS2_QTMUU0B, INTB_QTMUU0A, QTMU_Sweep, INTB_100K_Fovi, -1);	// BUS2 -> INTB(A->B)
	delay_ms(1);
	pwr0V_SET();
  // ======================================================================================== INTB DELAY 00h
	FOVI_INTB_100K.Set(FV, 5.0f, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	FOVI_SCL.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	FOVI_SDA.Set(FV, 3.3f, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_us(500);

	// I2C
	// R=03h, D=C0h
  IIC_WRITE(SLVaddr, 0x03, 0xC0);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON, 2);
	delay_ms(1);

	qtmu0.ChannelSetup(QTMU_PLUS_CHB_STOP);
	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_25V, QTMU_PLUS_FILTER_PASS);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_25V, QTMU_PLUS_FILTER_PASS);
	qtmu0.SetStartTrigger(5.5f, QTMU_PLUS_NEG_SLOPE);
	qtmu0.SetStopTrigger(1.0f, QTMU_PLUS_NEG_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_DUAL_SOURCE);
	qtmu0.Connect();
	delay_ms(1);
	
	qtmu0.SetSinglePulseMeas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 0);
	qtmu0.SetTimeOut(2);

	FPVI_VBUS1.Set(FV, 6.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	
	for(site = 0; site < SITENUM; site++ )  {
		qtmu0.SinglePlsMeas(site);
		tINTB_00[site] = qtmu0.GetMeasureResult(site);
 	}
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
  // ======================================================================================== INTB DELAY 01h
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON, 2);
	delay_us(500);
	// I2C
	// R=03h, D=C2h
  IIC_WRITE(SLVaddr, 0x03, 0xC2);

	qtmu0.SetSinglePulseMeas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 0);
	qtmu0.SetTimeOut(2);

	FPVI_VBUS1.Set(FV, 6.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	
	for(site = 0; site < SITENUM; site++ )  {
		qtmu0.SinglePlsMeas(site);
		tINTB_01[site] = qtmu0.GetMeasureResult(site);
 	}
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
#ifdef NonShrink
	// ======================================================================================== INTB DELAY 10h
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON, 2);
	delay_us(500);
	// I2C
	// R=03h, D=C4h
  IIC_WRITE(SLVaddr, 0x03, 0xC4);

	qtmu0.SetSinglePulseMeas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 0);
	qtmu0.SetTimeOut(3);

	FPVI_VBUS1.Set(FV, 6.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	
	for(site = 0; site < SITENUM; site++ )  {
		qtmu0.SinglePlsMeas(site);
		tINTB_10[site] = qtmu0.GetMeasureResult(site);
 	}
	FOVI_EN.Set(FV, 0.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 0.0f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_us(500);
	// ======================================================================================== INTB DELAY 11h
	FOVI_EN.Set(FV, 5.0f, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_us(500);
	FPVI_VBUS1.Set(FV, 5.0f, FPVI10_10V, FPVI10_1A, RELAY_ON, 2);
	delay_us(500);
	// I2C
	// R=03h, D=C6h
  IIC_WRITE(SLVaddr, 0x03, 0xC6);

	qtmu0.SetSinglePulseMeas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 0);
	qtmu0.SetTimeOut(8);

	FPVI_VBUS1.Set(FV, 6.5f, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	
	for(site = 0; site < SITENUM; site++ )  {
		qtmu0.SinglePlsMeas(site);
		tINTB_11[site] = qtmu0.GetMeasureResult(site);
 	}
#endif
	pwr0V_SET();
	pwrOFF_SET();
	cbit128.SetOn(-1);
	delay_ms(1);
	
	for(site = 0; site < SITENUM; site++ )  {
		TINTBDLY1_00->SetTestResult(site, 0, tINTB_00[site]);
		TINTBDLY1_01->SetTestResult(site, 0, tINTB_01[site]);
#ifdef NonShrink
		TINTBDLY1_10->SetTestResult(site, 0, tINTB_10[site]);
		TINTBDLY1_11->SetTestResult(site, 0, tINTB_11[site]);
#endif
 	}
	return 0;
}
// test23, -0.7 ~ -0.4 ***************************************** test23 *****************************************
DUT_API int reOS_TEST(short funcindex, LPCTSTR funclabel)	{
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IMON2_GND = StsGetParam(funcindex,"IMON2_GND");
    CParam *ADDR_GND = StsGetParam(funcindex,"ADDR_GND");
    CParam *FRSEN_GND = StsGetParam(funcindex,"FRSEN_GND");
    CParam *EN_GND = StsGetParam(funcindex,"EN_GND");
    CParam *VBUS2_GND = StsGetParam(funcindex,"VBUS2_GND");
    CParam *MOUT_GND = StsGetParam(funcindex,"MOUT_GND");
    CParam *VBUS1_GND = StsGetParam(funcindex,"VBUS1_GND");
    CParam *VCC_GND = StsGetParam(funcindex,"VCC_GND");
    CParam *SCL_GND = StsGetParam(funcindex,"SCL_GND");
    CParam *SDA_GND = StsGetParam(funcindex,"SDA_GND");
    CParam *INTB_GND = StsGetParam(funcindex,"INTB_GND");
    CParam *IMON1_GND = StsGetParam(funcindex,"IMON1_GND");
    CParam *MOUT_VBUS1 = StsGetParam(funcindex,"MOUT_VBUS1");
    CParam *MOUT_VBUS2 = StsGetParam(funcindex,"MOUT_VBUS2");
  //}}AFX_STS_PARAM_PROTOTYPES
  // TODO: Add your function code here
	cbit128.SetOn(-1);
	delay_ms(1);
	pwrVI_RLY(0);
	pwr0V_SET();

	// MOUT
	FPVI_MOUT.Set(FI, -1.0e-3, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_us(300);
	FPVI_MOUT.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		MOUT_GND->SetTestResult(site, 0, FPVI_MOUT.GetMeasResult(site, MVRET));
	FPVI_MOUT.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);

	// VBUS1
	FPVI_VBUS1.Set(FI, -1.0e-3, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_us(300);
	FPVI_VBUS1.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		VBUS1_GND->SetTestResult(site, 0, FPVI_VBUS1.GetMeasResult(site, MVRET));
	FPVI_VBUS1.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);

	// VBUS2
	FPVI_VBUS2.Set(FI, -1.0e-3, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_us(300);
	FPVI_VBUS2.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		VBUS2_GND->SetTestResult(site, 0, FPVI_VBUS2.GetMeasResult(site, MVRET));
	FPVI_VBUS2.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);

	// EN
	FOVI_EN.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_EN.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		EN_GND->SetTestResult(site, 0, FOVI_EN.GetMeasResult(site, MVRET));
	FOVI_EN.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// FRSEN
	FOVI_FRSEN.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_FRSEN.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		FRSEN_GND->SetTestResult(site, 0, FOVI_FRSEN.GetMeasResult(site, MVRET));
	FOVI_FRSEN.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// VCC
	FOVI_VCC.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_VCC.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		VCC_GND->SetTestResult(site, 0, FOVI_VCC.GetMeasResult(site, MVRET));
	FOVI_VCC.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// IMON1
	FOVI_IMON1.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_IMON1.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		IMON1_GND->SetTestResult(site, 0, FOVI_IMON1.GetMeasResult(site, MVRET));
	FOVI_IMON1.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// IMON2
	FOVI_IMON2.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_IMON2.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		IMON2_GND->SetTestResult(site, 0, FOVI_IMON2.GetMeasResult(site, MVRET));
	FOVI_IMON2.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// ADDR
	FOVI_ADDR.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_ADDR.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		ADDR_GND->SetTestResult(site, 0, FOVI_ADDR.GetMeasResult(site, MVRET));
	FOVI_ADDR.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// INTB
	FOVI_INTB.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_INTB.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		INTB_GND->SetTestResult(site, 0, FOVI_INTB.GetMeasResult(site, MVRET));
	FOVI_INTB.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// SCL
	FOVI_SCL.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_SCL.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		SCL_GND->SetTestResult(site, 0, FOVI_SCL.GetMeasResult(site, MVRET));
	FOVI_SCL.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// SDA
	FOVI_SDA.Set(FI, -1.0e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_us(300);
	FOVI_SDA.MeasureVI(10, 10);
	for(site=  0; site < SITENUM; site++)
		SDA_GND->SetTestResult(site, 0, FOVI_SDA.GetMeasResult(site, MVRET));
	FOVI_SDA.Set(FV, 0.0, FOVI_2V, FOVI_10MA, RELAY_ON);

	// ==============================================================================
  cbit128.SetOn(VBUS1_Fpvi, MOUT_Fpvi, -1);
	delay_ms(1);
	// MOUT
	FPVI_MOUT.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	// VBUS1
	FPVI_VBUS1.Set(FI, 1.0e-3, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_us(300);
	FPVI_VBUS1.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		MOUT_VBUS1->SetTestResult(site, 0, FPVI_VBUS1.GetMeasResult(site, MVRET));
	FPVI_VBUS1.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);

	// ==============================================================================
  cbit128.SetOn(VBUS2_Fpvi, MOUT_Fpvi, -1);
	delay_ms(1);
	// MOUT
	FPVI_MOUT.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	// VBUS2
	FPVI_VBUS2.Set(FI, 1.0e-3, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_us(300);
	FPVI_VBUS2.MeasureVI(10, 10);
	for(site = 0; site < SITENUM; site++)
		MOUT_VBUS2->SetTestResult(site, 0, FPVI_VBUS2.GetMeasResult(site, MVRET));
	FPVI_VBUS2.Set(FV, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);

  // =============================================================================
	pwrOFF_SET();
	cbit128.SetOn(-1);
	delay_us(100);

  return 0;
}
DUT_API int SiteCheck(short funcindex, LPCTSTR funclabel) {
  //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Site1Check = StsGetParam(funcindex,"Site1Check");
    CParam *Site2Check = StsGetParam(funcindex,"Site2Check");
  //}}AFX_STS_PARAM_PROTOTYPES

  // TODO: Add your function code here
	// R1 = 1K,		SITE1
	// R1 = 2K,		SITE2
	double vresult[SITENUM] = { 0.0f };
	
  cbit128.SetCBITOn(-1);
	// ***************************** SITE CHECK *****************************
	// ***************************** SITE CHECK *****************************
	foviSCHK.Set(FI, 1.0e-3, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_us(500);

	foviSCHK.MeasureVI(20, 10);
	for (site = 0; site < SITENUM; site++)	{
		if(site == 0)	Site1Check->SetTestResult(site, 0, foviSCHK.GetMeasResult(site, MVRET));
		if(site == 1)	Site2Check->SetTestResult(site, 0, foviSCHK.GetMeasResult(site, MVRET));
	}
	foviSCHK.Set(FV, 0.0f, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_us(500);
	foviSCHK.Set(FV, 0.0f, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_us(500);

  return 0;
}